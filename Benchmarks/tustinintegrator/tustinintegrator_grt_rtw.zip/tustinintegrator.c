/*
 * tustinintegrator.c
 *
 * Code generation for model "tustinintegrator".
 *
 * Model version              : 1.56
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Aug 28 14:04:57 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "tustinintegrator.h"
#include "tustinintegrator_private.h"

/* Block signals (default storage) */
B_tustinintegrator_T tustinintegrator_B;

/* Block states (default storage) */
DW_tustinintegrator_T tustinintegrator_DW;

/* External inputs (root inport signals with default storage) */
ExtU_tustinintegrator_T tustinintegrator_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_tustinintegrator_T tustinintegrator_Y;

/* Real-time model */
RT_MODEL_tustinintegrator_T tustinintegrator_M_;
RT_MODEL_tustinintegrator_T *const tustinintegrator_M = &tustinintegrator_M_;

/* Model step function */
void tustinintegrator_step(void)
{
  /* local block i/o variables */
  real_T rtb_Switch2;
  boolean_T rtb_RelationalOperator;
  real_T rtb_Switch1;
  real_T rtb_Switch;

  /* RelationalOperator: '<S3>/Relational Operator' incorporates:
   *  Inport: '<Root>/BL'
   *  Inport: '<Root>/TL'
   */
  rtb_RelationalOperator = (tustinintegrator_U.TL < tustinintegrator_U.BL);

  /* Switch: '<S3>/Switch1' incorporates:
   *  Inport: '<Root>/BL'
   *  Inport: '<Root>/TL'
   */
  if (rtb_RelationalOperator) {
    rtb_Switch1 = tustinintegrator_U.BL;
  } else {
    rtb_Switch1 = tustinintegrator_U.TL;
  }

  /* End of Switch: '<S3>/Switch1' */

  /* Switch: '<S1>/Switch' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   *  Gain: '<S1>/Gain'
   *  Inport: '<Root>/T'
   *  Inport: '<Root>/ic'
   *  Inport: '<Root>/reset'
   *  Inport: '<Root>/xin'
   *  Product: '<S1>/Product'
   *  Sum: '<S1>/Sum'
   *  Sum: '<S1>/Sum1'
   *  UnitDelay: '<S1>/Unit Delay'
   *  UnitDelay: '<S1>/Unit Delay1'
   */
  if (tustinintegrator_U.reset != 0.0) {
    rtb_Switch = tustinintegrator_U.ic;
  } else {
    rtb_Switch = (tustinintegrator_U.cmd + tustinintegrator_DW.UnitDelay_DSTATE)
      * tustinintegrator_P.Gain_Gain * tustinintegrator_U.T +
      tustinintegrator_DW.UnitDelay1_DSTATE;
  }

  /* End of Switch: '<S1>/Switch' */

  /* Switch: '<S2>/Switch2' incorporates:
   *  RelationalOperator: '<S2>/LowerRelop1'
   *  Switch: '<S3>/Switch2'
   */
  if (rtb_Switch > rtb_Switch1) {
    rtb_Switch2 = rtb_Switch1;
  } else {
    if (rtb_RelationalOperator) {
      /* Switch: '<S3>/Switch2' incorporates:
       *  Inport: '<Root>/TL'
       */
      rtb_Switch1 = tustinintegrator_U.TL;
    } else {
      /* Switch: '<S3>/Switch2' incorporates:
       *  Inport: '<Root>/BL'
       */
      rtb_Switch1 = tustinintegrator_U.BL;
    }

    /* Switch: '<S2>/Switch' incorporates:
     *  RelationalOperator: '<S2>/UpperRelop'
     */
    if (rtb_Switch < rtb_Switch1) {
      rtb_Switch2 = rtb_Switch1;
    } else {
      rtb_Switch2 = rtb_Switch;
    }

    /* End of Switch: '<S2>/Switch' */
  }

  /* End of Switch: '<S2>/Switch2' */

  /* Outport: '<Root>/yout' */
  tustinintegrator_Y.yout = rtb_Switch2;

  /* Sin: '<Root>/Sine Wave' */
  tustinintegrator_B.SineWave = sin(tustinintegrator_P.SineWave_Freq *
    tustinintegrator_M->Timing.t[0] + tustinintegrator_P.SineWave_Phase) *
    tustinintegrator_P.SineWave_Amp + tustinintegrator_P.SineWave_Bias;

  /* Matfile logging */
  rt_UpdateTXYLogVars(tustinintegrator_M->rtwLogInfo,
                      (tustinintegrator_M->Timing.t));

  /* Update for UnitDelay: '<S1>/Unit Delay1' */
  tustinintegrator_DW.UnitDelay1_DSTATE = rtb_Switch2;

  /* Update for UnitDelay: '<S1>/Unit Delay' incorporates:
   *  Inport: '<Root>/xin'
   */
  tustinintegrator_DW.UnitDelay_DSTATE = tustinintegrator_U.cmd;

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0s, 0.0s] */
    if ((rtmGetTFinal(tustinintegrator_M)!=-1) &&
        !((rtmGetTFinal(tustinintegrator_M)-tustinintegrator_M->Timing.t[0]) >
          tustinintegrator_M->Timing.t[0] * (DBL_EPSILON))) {
      rtmSetErrorStatus(tustinintegrator_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++tustinintegrator_M->Timing.clockTick0)) {
    ++tustinintegrator_M->Timing.clockTickH0;
  }

  tustinintegrator_M->Timing.t[0] = tustinintegrator_M->Timing.clockTick0 *
    tustinintegrator_M->Timing.stepSize0 +
    tustinintegrator_M->Timing.clockTickH0 *
    tustinintegrator_M->Timing.stepSize0 * 4294967296.0;

  {
    /* Update absolute timer for sample time: [0.1s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.1, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    tustinintegrator_M->Timing.clockTick1++;
    if (!tustinintegrator_M->Timing.clockTick1) {
      tustinintegrator_M->Timing.clockTickH1++;
    }
  }
}

/* Model initialize function */
void tustinintegrator_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)tustinintegrator_M, 0,
                sizeof(RT_MODEL_tustinintegrator_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&tustinintegrator_M->solverInfo,
                          &tustinintegrator_M->Timing.simTimeStep);
    rtsiSetTPtr(&tustinintegrator_M->solverInfo, &rtmGetTPtr(tustinintegrator_M));
    rtsiSetStepSizePtr(&tustinintegrator_M->solverInfo,
                       &tustinintegrator_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&tustinintegrator_M->solverInfo, (&rtmGetErrorStatus
      (tustinintegrator_M)));
    rtsiSetRTModelPtr(&tustinintegrator_M->solverInfo, tustinintegrator_M);
  }

  rtsiSetSimTimeStep(&tustinintegrator_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&tustinintegrator_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(tustinintegrator_M, &tustinintegrator_M->Timing.tArray[0]);
  rtmSetTFinal(tustinintegrator_M, 10.0);
  tustinintegrator_M->Timing.stepSize0 = 0.1;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    tustinintegrator_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(tustinintegrator_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(tustinintegrator_M->rtwLogInfo, (NULL));
    rtliSetLogT(tustinintegrator_M->rtwLogInfo, "tout");
    rtliSetLogX(tustinintegrator_M->rtwLogInfo, "");
    rtliSetLogXFinal(tustinintegrator_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(tustinintegrator_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(tustinintegrator_M->rtwLogInfo, 2);
    rtliSetLogMaxRows(tustinintegrator_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(tustinintegrator_M->rtwLogInfo, 1);

    /*
     * Set pointers to the data and signal info for each output
     */
    {
      static void * rt_LoggedOutputSignalPtrs[] = {
        &tustinintegrator_Y.yout
      };

      rtliSetLogYSignalPtrs(tustinintegrator_M->rtwLogInfo, ((LogSignalPtrsType)
        rt_LoggedOutputSignalPtrs));
    }

    {
      static int_T rt_LoggedOutputWidths[] = {
        1
      };

      static int_T rt_LoggedOutputNumDimensions[] = {
        1
      };

      static int_T rt_LoggedOutputDimensions[] = {
        1
      };

      static boolean_T rt_LoggedOutputIsVarDims[] = {
        0
      };

      static void* rt_LoggedCurrentSignalDimensions[] = {
        (NULL)
      };

      static int_T rt_LoggedCurrentSignalDimensionsSize[] = {
        4
      };

      static BuiltInDTypeId rt_LoggedOutputDataTypeIds[] = {
        SS_DOUBLE
      };

      static int_T rt_LoggedOutputComplexSignals[] = {
        0
      };

      static RTWPreprocessingFcnPtr rt_LoggingPreprocessingFcnPtrs[] = {
        (NULL)
      };

      static const char_T *rt_LoggedOutputLabels[] = {
        "" };

      static const char_T *rt_LoggedOutputBlockNames[] = {
        "tustinintegrator/yout" };

      static RTWLogDataTypeConvert rt_RTWLogDataTypeConvert[] = {
        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 }
      };

      static RTWLogSignalInfo rt_LoggedOutputSignalInfo[] = {
        {
          1,
          rt_LoggedOutputWidths,
          rt_LoggedOutputNumDimensions,
          rt_LoggedOutputDimensions,
          rt_LoggedOutputIsVarDims,
          rt_LoggedCurrentSignalDimensions,
          rt_LoggedCurrentSignalDimensionsSize,
          rt_LoggedOutputDataTypeIds,
          rt_LoggedOutputComplexSignals,
          (NULL),
          rt_LoggingPreprocessingFcnPtrs,

          { rt_LoggedOutputLabels },
          (NULL),
          (NULL),
          (NULL),

          { rt_LoggedOutputBlockNames },

          { (NULL) },
          (NULL),
          rt_RTWLogDataTypeConvert
        }
      };

      rtliSetLogYSignalInfo(tustinintegrator_M->rtwLogInfo,
                            rt_LoggedOutputSignalInfo);

      /* set currSigDims field */
      rt_LoggedCurrentSignalDimensions[0] = &rt_LoggedOutputWidths[0];
    }

    rtliSetLogY(tustinintegrator_M->rtwLogInfo, "varout");
  }

  /* block I/O */
  (void) memset(((void *) &tustinintegrator_B), 0,
                sizeof(B_tustinintegrator_T));

  /* states (dwork) */
  (void) memset((void *)&tustinintegrator_DW, 0,
                sizeof(DW_tustinintegrator_T));

  /* external inputs */
  (void)memset(&tustinintegrator_U, 0, sizeof(ExtU_tustinintegrator_T));

  /* external outputs */
  tustinintegrator_Y.yout = 0.0;

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(tustinintegrator_M->rtwLogInfo, 0.0,
    rtmGetTFinal(tustinintegrator_M), tustinintegrator_M->Timing.stepSize0,
    (&rtmGetErrorStatus(tustinintegrator_M)));

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay1' */
  tustinintegrator_DW.UnitDelay1_DSTATE =
    tustinintegrator_P.UnitDelay1_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay' */
  tustinintegrator_DW.UnitDelay_DSTATE =
    tustinintegrator_P.UnitDelay_InitialCondition;
}

/* Model terminate function */
void tustinintegrator_terminate(void)
{
  /* (no terminate code required) */
}
