/*
 * euler321_I2B_12B_types.h
 *
 * Code generation for model "euler321_I2B_12B".
 *
 * Model version              : 1.44
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Fri Aug 27 10:33:21 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_euler321_I2B_12B_types_h_
#define RTW_HEADER_euler321_I2B_12B_types_h_

/* Model Code Variants */

/* Forward declaration for rtModel */
typedef struct tag_RTM_euler321_I2B_12B_T RT_MODEL_euler321_I2B_12B_T;

#endif                                /* RTW_HEADER_euler321_I2B_12B_types_h_ */
