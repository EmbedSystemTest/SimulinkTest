/*
 * bscfsm.c
 *
 * Code generation for model "bscfsm".
 *
 * Model version              : 1.102
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Aug 28 13:59:13 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "bscfsm.h"
#include "bscfsm_private.h"

/* Block signals (default storage) */
B_bscfsm_T bscfsm_B;

/* Block states (default storage) */
DW_bscfsm_T bscfsm_DW;

/* External inputs (root inport signals with default storage) */
ExtU_bscfsm_T bscfsm_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_bscfsm_T bscfsm_Y;

/* Real-time model */
RT_MODEL_bscfsm_T bscfsm_M_;
RT_MODEL_bscfsm_T *const bscfsm_M = &bscfsm_M_;

/* Model step function */
void bscfsm_step(void)
{
  real_T rtb_UnitDelay;
  boolean_T rtb_Switch2_a;

  /* UnitDelay: '<S1>/Unit Delay' */
  rtb_UnitDelay = bscfsm_DW.UnitDelay_DSTATE;

  /* If: '<S4>/If' */
  if (rtb_UnitDelay == 0.0) {
    /* Outputs for IfAction SubSystem: '<S4>/Transition' incorporates:
     *  ActionPort: '<S9>/Action Port'
     */
    /* Switch: '<S9>/Switch2' incorporates:
     *  DataTypeConversion: '<Root>/Data Type Conversion'
     *  DataTypeConversion: '<Root>/Data Type Conversion2'
     *  Inport: '<Root>/standby'
     *  Inport: '<Root>/supported'
     *  Logic: '<S9>/Logical Operator12'
     *  Switch: '<S9>/Switch1'
     *  UnitDelay: '<S1>/Unit Delay2'
     */
    if (bscfsm_U.standby != 0.0) {
      /* SignalConversion: '<S9>/Signal Conversion' incorporates:
       *  Constant: '<S9>/Constant1'
       */
      bscfsm_B.Merge = bscfsm_P.Constant1_Value;
    } else if ((bscfsm_U.supported != 0.0) && bscfsm_DW.UnitDelay2_DSTATE) {
      /* Switch: '<S9>/Switch1' incorporates:
       *  Constant: '<S9>/Constant7'
       *  SignalConversion: '<S9>/Signal Conversion'
       */
      bscfsm_B.Merge = bscfsm_P.Constant7_Value;
    } else {
      /* SignalConversion: '<S9>/Signal Conversion' incorporates:
       *  Switch: '<S9>/Switch1'
       */
      bscfsm_B.Merge = rtb_UnitDelay;
    }

    /* End of Switch: '<S9>/Switch2' */
    /* End of Outputs for SubSystem: '<S4>/Transition' */
  } else if (rtb_UnitDelay == 1.0) {
    /* Outputs for IfAction SubSystem: '<S4>/Nominal' incorporates:
     *  ActionPort: '<S7>/Action Port'
     */
    /* Switch: '<S7>/Switch2' incorporates:
     *  DataTypeConversion: '<Root>/Data Type Conversion'
     *  Inport: '<Root>/standby'
     *  Logic: '<S7>/Logical Operator12'
     *  Switch: '<S7>/Switch1'
     *  UnitDelay: '<S1>/Unit Delay2'
     */
    if (bscfsm_U.standby != 0.0) {
      /* SignalConversion: '<S7>/Signal Conversion' incorporates:
       *  Constant: '<S7>/Constant1'
       */
      bscfsm_B.Merge = bscfsm_P.Constant1_Value_o;
    } else if (!bscfsm_DW.UnitDelay2_DSTATE) {
      /* Switch: '<S7>/Switch1' incorporates:
       *  Constant: '<S7>/Constant7'
       *  SignalConversion: '<S7>/Signal Conversion'
       */
      bscfsm_B.Merge = bscfsm_P.Constant7_Value_i;
    } else {
      /* SignalConversion: '<S7>/Signal Conversion' incorporates:
       *  Switch: '<S7>/Switch1'
       */
      bscfsm_B.Merge = 1.0;
    }

    /* End of Switch: '<S7>/Switch2' */
    /* End of Outputs for SubSystem: '<S4>/Nominal' */
  } else if (rtb_UnitDelay == 2.0) {
    /* Outputs for IfAction SubSystem: '<S4>/Maneuver' incorporates:
     *  ActionPort: '<S6>/Action Port'
     */
    /* Switch: '<S6>/Switch2' incorporates:
     *  DataTypeConversion: '<Root>/Data Type Conversion'
     *  DataTypeConversion: '<Root>/Data Type Conversion2'
     *  Inport: '<Root>/standby'
     *  Inport: '<Root>/supported'
     *  Logic: '<S6>/Logical Operator1'
     *  Logic: '<S6>/Logical Operator12'
     *  Switch: '<S6>/Switch1'
     *  UnitDelay: '<S1>/Unit Delay2'
     */
    if ((bscfsm_U.standby != 0.0) && bscfsm_DW.UnitDelay2_DSTATE) {
      /* SignalConversion: '<S6>/Signal Conversion' incorporates:
       *  Constant: '<S6>/Constant1'
       */
      bscfsm_B.Merge = bscfsm_P.Constant1_Value_ot;
    } else if ((bscfsm_U.supported != 0.0) && bscfsm_DW.UnitDelay2_DSTATE) {
      /* Switch: '<S6>/Switch1' incorporates:
       *  Constant: '<S6>/Constant7'
       *  SignalConversion: '<S6>/Signal Conversion'
       */
      bscfsm_B.Merge = bscfsm_P.Constant7_Value_n;
    } else {
      /* SignalConversion: '<S6>/Signal Conversion' incorporates:
       *  Switch: '<S6>/Switch1'
       */
      bscfsm_B.Merge = 2.0;
    }

    /* End of Switch: '<S6>/Switch2' */
    /* End of Outputs for SubSystem: '<S4>/Maneuver' */
  } else {
    if (rtb_UnitDelay == 3.0) {
      /* Outputs for IfAction SubSystem: '<S4>/Standby' incorporates:
       *  ActionPort: '<S8>/Action Port'
       */
      /* Switch: '<S8>/Switch2' incorporates:
       *  DataTypeConversion: '<Root>/Data Type Conversion'
       *  DataTypeConversion: '<Root>/Data Type Conversion1'
       *  Inport: '<Root>/apfail'
       *  Inport: '<Root>/standby'
       *  Logic: '<S8>/Logical Operator12'
       *  Switch: '<S8>/Switch1'
       */
      if (bscfsm_U.apfail != 0.0) {
        /* SignalConversion: '<S8>/Signal Conversion' incorporates:
         *  Constant: '<S8>/Constant1'
         */
        bscfsm_B.Merge = bscfsm_P.Constant1_Value_j;
      } else if (!(bscfsm_U.standby != 0.0)) {
        /* Switch: '<S8>/Switch1' incorporates:
         *  Constant: '<S8>/Constant7'
         *  SignalConversion: '<S8>/Signal Conversion'
         */
        bscfsm_B.Merge = bscfsm_P.Constant7_Value_a;
      } else {
        /* SignalConversion: '<S8>/Signal Conversion' incorporates:
         *  Switch: '<S8>/Switch1'
         */
        bscfsm_B.Merge = 3.0;
      }

      /* End of Switch: '<S8>/Switch2' */
      /* End of Outputs for SubSystem: '<S4>/Standby' */
    }
  }

  /* End of If: '<S4>/If' */

  /* If: '<S5>/If' incorporates:
   *  Constant: '<S10>/Constant10'
   *  Constant: '<S10>/Constant11'
   *  Constant: '<S10>/Constant9'
   *  Constant: '<S11>/Constant3'
   *  Constant: '<S11>/Constant4'
   *  Constant: '<S11>/Constant5'
   *  Constant: '<S12>/Constant1'
   *  Constant: '<S12>/Constant11'
   *  Constant: '<S12>/Constant9'
   *  Constant: '<S13>/Constant16'
   *  Constant: '<S13>/Constant17'
   *  Constant: '<S13>/Constant18'
   */
  if (bscfsm_B.Merge == 0.0) {
    /* Outputs for IfAction SubSystem: '<S5>/Transition' incorporates:
     *  ActionPort: '<S13>/Action Port'
     */
    bscfsm_B.Merge_p[0] = bscfsm_P.Constant16_Value;
    bscfsm_B.Merge_p[1] = bscfsm_P.Constant17_Value;
    bscfsm_B.Merge_p[2] = bscfsm_P.Constant18_Value;

    /* End of Outputs for SubSystem: '<S5>/Transition' */
  } else if (bscfsm_B.Merge == 1.0) {
    /* Outputs for IfAction SubSystem: '<S5>/Nominal' incorporates:
     *  ActionPort: '<S11>/Action Port'
     */
    bscfsm_B.Merge_p[0] = bscfsm_P.Constant3_Value;
    bscfsm_B.Merge_p[1] = bscfsm_P.Constant4_Value;
    bscfsm_B.Merge_p[2] = bscfsm_P.Constant5_Value;

    /* End of Outputs for SubSystem: '<S5>/Nominal' */
  } else if (bscfsm_B.Merge == 2.0) {
    /* Outputs for IfAction SubSystem: '<S5>/Maneuver' incorporates:
     *  ActionPort: '<S10>/Action Port'
     */
    bscfsm_B.Merge_p[1] = bscfsm_P.Constant10_Value;
    bscfsm_B.Merge_p[2] = bscfsm_P.Constant11_Value;
    bscfsm_B.Merge_p[0] = bscfsm_P.Constant9_Value;

    /* End of Outputs for SubSystem: '<S5>/Maneuver' */
  } else {
    if (bscfsm_B.Merge == 3.0) {
      /* Outputs for IfAction SubSystem: '<S5>/Standby' incorporates:
       *  ActionPort: '<S12>/Action Port'
       */
      bscfsm_B.Merge_p[1] = bscfsm_P.Constant1_Value_ol;
      bscfsm_B.Merge_p[2] = bscfsm_P.Constant11_Value_k;
      bscfsm_B.Merge_p[0] = bscfsm_P.Constant9_Value_b;

      /* End of Outputs for SubSystem: '<S5>/Standby' */
    }
  }

  /* End of If: '<S5>/If' */

  /* Outport: '<Root>/pullup' */
  bscfsm_Y.pullup = bscfsm_B.Merge_p[2];

  /* Outport: '<Root>/state' */
  bscfsm_Y.state = bscfsm_B.Merge;

  /* UnitDelay: '<S1>/Unit Delay1' */
  rtb_UnitDelay = bscfsm_DW.UnitDelay1_DSTATE;

  /* If: '<S14>/If' */
  if (rtb_UnitDelay == 0.0) {
    /* Outputs for IfAction SubSystem: '<S14>/Nominal' incorporates:
     *  ActionPort: '<S17>/Action Port'
     */
    /* Switch: '<S17>/Switch2' incorporates:
     *  DataTypeConversion: '<Root>/Data Type Conversion3'
     *  Inport: '<Root>/limits'
     *  Logic: '<S17>/Logical Operator12'
     *  Switch: '<S17>/Switch1'
     */
    if (bscfsm_U.limits != 0.0) {
      /* SignalConversion: '<S17>/Signal Conversion' incorporates:
       *  Constant: '<S17>/Constant1'
       */
      bscfsm_B.Merge_g = bscfsm_P.Constant1_Value_e;
    } else if (!bscfsm_B.Merge_p[1]) {
      /* Switch: '<S17>/Switch1' incorporates:
       *  Constant: '<S17>/Constant7'
       *  SignalConversion: '<S17>/Signal Conversion'
       */
      bscfsm_B.Merge_g = bscfsm_P.Constant7_Value_k;
    } else {
      /* SignalConversion: '<S17>/Signal Conversion' incorporates:
       *  Switch: '<S17>/Switch1'
       */
      bscfsm_B.Merge_g = rtb_UnitDelay;
    }

    /* End of Switch: '<S17>/Switch2' */
    /* End of Outputs for SubSystem: '<S14>/Nominal' */
  } else if (rtb_UnitDelay == 1.0) {
    /* Outputs for IfAction SubSystem: '<S14>/Transition' incorporates:
     *  ActionPort: '<S18>/Action Port'
     */
    /* Switch: '<S18>/Switch1' incorporates:
     *  Logic: '<S18>/Logical Operator12'
     */
    if (bscfsm_B.Merge_p[1] && bscfsm_B.Merge_p[0]) {
      /* SignalConversion: '<S18>/Signal Conversion' incorporates:
       *  Constant: '<S18>/Constant7'
       */
      bscfsm_B.Merge_g = bscfsm_P.Constant7_Value_c;
    } else {
      /* SignalConversion: '<S18>/Signal Conversion' */
      bscfsm_B.Merge_g = 1.0;
    }

    /* End of Switch: '<S18>/Switch1' */
    /* End of Outputs for SubSystem: '<S14>/Transition' */
  } else {
    if (rtb_UnitDelay == 2.0) {
      /* Outputs for IfAction SubSystem: '<S14>/Fault' incorporates:
       *  ActionPort: '<S16>/Action Port'
       */
      /* Switch: '<S16>/Switch1' incorporates:
       *  DataTypeConversion: '<Root>/Data Type Conversion3'
       *  Inport: '<Root>/limits'
       *  Logic: '<S16>/Logical Operator12'
       *  Logic: '<S16>/Logical Operator2'
       *  Logic: '<S16>/Logical Operator3'
       */
      if ((!bscfsm_B.Merge_p[1]) || (!(bscfsm_U.limits != 0.0))) {
        /* SignalConversion: '<S16>/Signal Conversion' incorporates:
         *  Constant: '<S16>/Constant7'
         */
        bscfsm_B.Merge_g = bscfsm_P.Constant7_Value_im;
      } else {
        /* SignalConversion: '<S16>/Signal Conversion' */
        bscfsm_B.Merge_g = 2.0;
      }

      /* End of Switch: '<S16>/Switch1' */
      /* End of Outputs for SubSystem: '<S14>/Fault' */
    }
  }

  /* End of If: '<S14>/If' */

  /* Switch: '<S15>/Switch2' incorporates:
   *  Constant: '<S15>/Constant12'
   *  Constant: '<S15>/Constant6'
   *  Constant: '<S15>/Constant9'
   *  RelationalOperator: '<S15>/Relational Operator5'
   */
  if (bscfsm_B.Merge_g == bscfsm_P.Constant6_Value) {
    rtb_Switch2_a = bscfsm_P.Constant9_Value_g;
  } else {
    rtb_Switch2_a = bscfsm_P.Constant12_Value;
  }

  /* End of Switch: '<S15>/Switch2' */

  /* Outport: '<Root>/good' */
  bscfsm_Y.good = rtb_Switch2_a;

  /* Outport: '<Root>/SENSTATE' */
  bscfsm_Y.SENSTATE = bscfsm_B.Merge_g;

  /* Outport: '<Root>/MODE' */
  bscfsm_Y.MODE = bscfsm_B.Merge_p[0];

  /* Outport: '<Root>/REQUEST' */
  bscfsm_Y.REQUEST = bscfsm_B.Merge_p[1];

  /* Update for UnitDelay: '<S1>/Unit Delay' */
  bscfsm_DW.UnitDelay_DSTATE = bscfsm_B.Merge;

  /* Update for UnitDelay: '<S1>/Unit Delay2' */
  bscfsm_DW.UnitDelay2_DSTATE = rtb_Switch2_a;

  /* Update for UnitDelay: '<S1>/Unit Delay1' */
  bscfsm_DW.UnitDelay1_DSTATE = bscfsm_B.Merge_g;

  /* Matfile logging */
  rt_UpdateTXYLogVars(bscfsm_M->rtwLogInfo, (&bscfsm_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.2s, 0.0s] */
    if ((rtmGetTFinal(bscfsm_M)!=-1) &&
        !((rtmGetTFinal(bscfsm_M)-bscfsm_M->Timing.taskTime0) >
          bscfsm_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(bscfsm_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++bscfsm_M->Timing.clockTick0)) {
    ++bscfsm_M->Timing.clockTickH0;
  }

  bscfsm_M->Timing.taskTime0 = bscfsm_M->Timing.clockTick0 *
    bscfsm_M->Timing.stepSize0 + bscfsm_M->Timing.clockTickH0 *
    bscfsm_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void bscfsm_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)bscfsm_M, 0,
                sizeof(RT_MODEL_bscfsm_T));
  rtmSetTFinal(bscfsm_M, 10.0);
  bscfsm_M->Timing.stepSize0 = 0.2;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    bscfsm_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(bscfsm_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(bscfsm_M->rtwLogInfo, (NULL));
    rtliSetLogT(bscfsm_M->rtwLogInfo, "tout");
    rtliSetLogX(bscfsm_M->rtwLogInfo, "");
    rtliSetLogXFinal(bscfsm_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(bscfsm_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(bscfsm_M->rtwLogInfo, 2);
    rtliSetLogMaxRows(bscfsm_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(bscfsm_M->rtwLogInfo, 1);

    /*
     * Set pointers to the data and signal info for each output
     */
    {
      static void * rt_LoggedOutputSignalPtrs[] = {
        &bscfsm_Y.pullup,
        &bscfsm_Y.state,
        &bscfsm_Y.good,
        &bscfsm_Y.SENSTATE,
        &bscfsm_Y.MODE,
        &bscfsm_Y.REQUEST
      };

      rtliSetLogYSignalPtrs(bscfsm_M->rtwLogInfo, ((LogSignalPtrsType)
        rt_LoggedOutputSignalPtrs));
    }

    {
      static int_T rt_LoggedOutputWidths[] = {
        1,
        1,
        1,
        1,
        1,
        1
      };

      static int_T rt_LoggedOutputNumDimensions[] = {
        1,
        1,
        1,
        1,
        1,
        1
      };

      static int_T rt_LoggedOutputDimensions[] = {
        1,
        1,
        1,
        1,
        1,
        1
      };

      static boolean_T rt_LoggedOutputIsVarDims[] = {
        0,
        0,
        0,
        0,
        0,
        0
      };

      static void* rt_LoggedCurrentSignalDimensions[] = {
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL)
      };

      static int_T rt_LoggedCurrentSignalDimensionsSize[] = {
        4,
        4,
        4,
        4,
        4,
        4
      };

      static BuiltInDTypeId rt_LoggedOutputDataTypeIds[] = {
        SS_BOOLEAN,
        SS_DOUBLE,
        SS_BOOLEAN,
        SS_DOUBLE,
        SS_BOOLEAN,
        SS_BOOLEAN
      };

      static int_T rt_LoggedOutputComplexSignals[] = {
        0,
        0,
        0,
        0,
        0,
        0
      };

      static RTWPreprocessingFcnPtr rt_LoggingPreprocessingFcnPtrs[] = {
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL)
      };

      static const char_T *rt_LoggedOutputLabels[] = {
        "",
        "",
        "",
        "",
        "",
        "" };

      static const char_T *rt_LoggedOutputBlockNames[] = {
        "bscfsm/pullup",
        "bscfsm/state",
        "bscfsm/good",
        "bscfsm/SENSTATE",
        "bscfsm/MODE",
        "bscfsm/REQUEST" };

      static RTWLogDataTypeConvert rt_RTWLogDataTypeConvert[] = {
        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 }
      };

      static RTWLogSignalInfo rt_LoggedOutputSignalInfo[] = {
        {
          6,
          rt_LoggedOutputWidths,
          rt_LoggedOutputNumDimensions,
          rt_LoggedOutputDimensions,
          rt_LoggedOutputIsVarDims,
          rt_LoggedCurrentSignalDimensions,
          rt_LoggedCurrentSignalDimensionsSize,
          rt_LoggedOutputDataTypeIds,
          rt_LoggedOutputComplexSignals,
          (NULL),
          rt_LoggingPreprocessingFcnPtrs,

          { rt_LoggedOutputLabels },
          (NULL),
          (NULL),
          (NULL),

          { rt_LoggedOutputBlockNames },

          { (NULL) },
          (NULL),
          rt_RTWLogDataTypeConvert
        }
      };

      rtliSetLogYSignalInfo(bscfsm_M->rtwLogInfo, rt_LoggedOutputSignalInfo);

      /* set currSigDims field */
      rt_LoggedCurrentSignalDimensions[0] = &rt_LoggedOutputWidths[0];
      rt_LoggedCurrentSignalDimensions[1] = &rt_LoggedOutputWidths[1];
      rt_LoggedCurrentSignalDimensions[2] = &rt_LoggedOutputWidths[2];
      rt_LoggedCurrentSignalDimensions[3] = &rt_LoggedOutputWidths[3];
      rt_LoggedCurrentSignalDimensions[4] = &rt_LoggedOutputWidths[4];
      rt_LoggedCurrentSignalDimensions[5] = &rt_LoggedOutputWidths[5];
    }

    rtliSetLogY(bscfsm_M->rtwLogInfo, "yout");
  }

  /* block I/O */
  (void) memset(((void *) &bscfsm_B), 0,
                sizeof(B_bscfsm_T));

  /* states (dwork) */
  (void) memset((void *)&bscfsm_DW, 0,
                sizeof(DW_bscfsm_T));

  /* external inputs */
  (void)memset(&bscfsm_U, 0, sizeof(ExtU_bscfsm_T));

  /* external outputs */
  (void) memset((void *)&bscfsm_Y, 0,
                sizeof(ExtY_bscfsm_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(bscfsm_M->rtwLogInfo, 0.0, rtmGetTFinal
    (bscfsm_M), bscfsm_M->Timing.stepSize0, (&rtmGetErrorStatus(bscfsm_M)));

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay' */
  bscfsm_DW.UnitDelay_DSTATE = bscfsm_P.UnitDelay_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay2' */
  bscfsm_DW.UnitDelay2_DSTATE = bscfsm_P.UnitDelay2_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay1' */
  bscfsm_DW.UnitDelay1_DSTATE = bscfsm_P.UnitDelay1_InitialCondition;
}

/* Model terminate function */
void bscfsm_terminate(void)
{
  /* (no terminate code required) */
}
