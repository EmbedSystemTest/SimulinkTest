/*
 * bscfsm.h
 *
 * Code generation for model "bscfsm".
 *
 * Model version              : 1.102
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Aug 28 13:59:13 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_bscfsm_h_
#define RTW_HEADER_bscfsm_h_
#include <string.h>
#include <float.h>
#include <stddef.h>
#ifndef bscfsm_COMMON_INCLUDES_
# define bscfsm_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                                 /* bscfsm_COMMON_INCLUDES_ */

#include "bscfsm_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               (&(rtm)->Timing.taskTime0)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Merge;                        /* '<S4>/Merge' */
  real_T Merge_g;                      /* '<S14>/Merge' */
  boolean_T Merge_p[3];                /* '<S5>/Merge' */
} B_bscfsm_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T UnitDelay_DSTATE;             /* '<S1>/Unit Delay' */
  real_T UnitDelay1_DSTATE;            /* '<S1>/Unit Delay1' */
  boolean_T UnitDelay2_DSTATE;         /* '<S1>/Unit Delay2' */
} DW_bscfsm_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T standby;                      /* '<Root>/standby' */
  real_T apfail;                       /* '<Root>/apfail' */
  real_T supported;                    /* '<Root>/supported' */
  real_T limits;                       /* '<Root>/limits' */
} ExtU_bscfsm_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  boolean_T pullup;                    /* '<Root>/pullup' */
  real_T state;                        /* '<Root>/state' */
  boolean_T good;                      /* '<Root>/good' */
  real_T SENSTATE;                     /* '<Root>/SENSTATE' */
  boolean_T MODE;                      /* '<Root>/MODE' */
  boolean_T REQUEST;                   /* '<Root>/REQUEST' */
} ExtY_bscfsm_T;

/* Parameters (default storage) */
struct P_bscfsm_T_ {
  real_T Constant7_Value;              /* Expression: 1.0
                                        * Referenced by: '<S9>/Constant7'
                                        */
  real_T Constant1_Value;              /* Expression: 3.0
                                        * Referenced by: '<S9>/Constant1'
                                        */
  real_T Constant7_Value_i;            /* Expression: 2.0
                                        * Referenced by: '<S7>/Constant7'
                                        */
  real_T Constant1_Value_o;            /* Expression: 3.0
                                        * Referenced by: '<S7>/Constant1'
                                        */
  real_T Constant7_Value_n;            /* Expression: 0.0
                                        * Referenced by: '<S6>/Constant7'
                                        */
  real_T Constant1_Value_ot;           /* Expression: 3.0
                                        * Referenced by: '<S6>/Constant1'
                                        */
  real_T Constant7_Value_a;            /* Expression: 0.0
                                        * Referenced by: '<S8>/Constant7'
                                        */
  real_T Constant1_Value_j;            /* Expression: 2.0
                                        * Referenced by: '<S8>/Constant1'
                                        */
  real_T Constant7_Value_k;            /* Expression: 1.0
                                        * Referenced by: '<S17>/Constant7'
                                        */
  real_T Constant1_Value_e;            /* Expression: 2.0
                                        * Referenced by: '<S17>/Constant1'
                                        */
  real_T Constant7_Value_c;            /* Expression: 0.0
                                        * Referenced by: '<S18>/Constant7'
                                        */
  real_T Constant7_Value_im;           /* Expression: 1.0
                                        * Referenced by: '<S16>/Constant7'
                                        */
  real_T UnitDelay_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S1>/Unit Delay'
                                        */
  real_T UnitDelay1_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Unit Delay1'
                                        */
  real_T Constant6_Value;              /* Expression: 2
                                        * Referenced by: '<S15>/Constant6'
                                        */
  boolean_T Constant16_Value;          /* Computed Parameter: Constant16_Value
                                        * Referenced by: '<S13>/Constant16'
                                        */
  boolean_T Constant17_Value;          /* Computed Parameter: Constant17_Value
                                        * Referenced by: '<S13>/Constant17'
                                        */
  boolean_T Constant18_Value;          /* Computed Parameter: Constant18_Value
                                        * Referenced by: '<S13>/Constant18'
                                        */
  boolean_T Constant3_Value;           /* Computed Parameter: Constant3_Value
                                        * Referenced by: '<S11>/Constant3'
                                        */
  boolean_T Constant4_Value;           /* Computed Parameter: Constant4_Value
                                        * Referenced by: '<S11>/Constant4'
                                        */
  boolean_T Constant5_Value;           /* Computed Parameter: Constant5_Value
                                        * Referenced by: '<S11>/Constant5'
                                        */
  boolean_T Constant10_Value;          /* Computed Parameter: Constant10_Value
                                        * Referenced by: '<S10>/Constant10'
                                        */
  boolean_T Constant11_Value;          /* Computed Parameter: Constant11_Value
                                        * Referenced by: '<S10>/Constant11'
                                        */
  boolean_T Constant9_Value;           /* Computed Parameter: Constant9_Value
                                        * Referenced by: '<S10>/Constant9'
                                        */
  boolean_T Constant1_Value_ol;        /* Computed Parameter: Constant1_Value_ol
                                        * Referenced by: '<S12>/Constant1'
                                        */
  boolean_T Constant11_Value_k;        /* Computed Parameter: Constant11_Value_k
                                        * Referenced by: '<S12>/Constant11'
                                        */
  boolean_T Constant9_Value_b;         /* Computed Parameter: Constant9_Value_b
                                        * Referenced by: '<S12>/Constant9'
                                        */
  boolean_T Constant12_Value;          /* Computed Parameter: Constant12_Value
                                        * Referenced by: '<S15>/Constant12'
                                        */
  boolean_T Constant9_Value_g;         /* Computed Parameter: Constant9_Value_g
                                        * Referenced by: '<S15>/Constant9'
                                        */
  boolean_T UnitDelay2_InitialCondition;
                              /* Computed Parameter: UnitDelay2_InitialCondition
                               * Referenced by: '<S1>/Unit Delay2'
                               */
};

/* Real-time Model Data Structure */
struct tag_RTM_bscfsm_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_bscfsm_T bscfsm_P;

/* Block signals (default storage) */
extern B_bscfsm_T bscfsm_B;

/* Block states (default storage) */
extern DW_bscfsm_T bscfsm_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_bscfsm_T bscfsm_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_bscfsm_T bscfsm_Y;

/* Model entry point functions */
extern void bscfsm_initialize(void);
extern void bscfsm_step(void);
extern void bscfsm_terminate(void);

/* Real-time Model object */
extern RT_MODEL_bscfsm_T *const bscfsm_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'bscfsm'
 * '<S1>'   : 'bscfsm/FiniteStateMachine'
 * '<S2>'   : 'bscfsm/FiniteStateMachine/Manager'
 * '<S3>'   : 'bscfsm/FiniteStateMachine/Sen'
 * '<S4>'   : 'bscfsm/FiniteStateMachine/Manager/Actions'
 * '<S5>'   : 'bscfsm/FiniteStateMachine/Manager/Output'
 * '<S6>'   : 'bscfsm/FiniteStateMachine/Manager/Actions/Maneuver'
 * '<S7>'   : 'bscfsm/FiniteStateMachine/Manager/Actions/Nominal'
 * '<S8>'   : 'bscfsm/FiniteStateMachine/Manager/Actions/Standby'
 * '<S9>'   : 'bscfsm/FiniteStateMachine/Manager/Actions/Transition'
 * '<S10>'  : 'bscfsm/FiniteStateMachine/Manager/Output/Maneuver'
 * '<S11>'  : 'bscfsm/FiniteStateMachine/Manager/Output/Nominal'
 * '<S12>'  : 'bscfsm/FiniteStateMachine/Manager/Output/Standby'
 * '<S13>'  : 'bscfsm/FiniteStateMachine/Manager/Output/Transition'
 * '<S14>'  : 'bscfsm/FiniteStateMachine/Sen/Actions'
 * '<S15>'  : 'bscfsm/FiniteStateMachine/Sen/Output'
 * '<S16>'  : 'bscfsm/FiniteStateMachine/Sen/Actions/Fault'
 * '<S17>'  : 'bscfsm/FiniteStateMachine/Sen/Actions/Nominal'
 * '<S18>'  : 'bscfsm/FiniteStateMachine/Sen/Actions/Transition'
 */
#endif                                 /* RTW_HEADER_bscfsm_h_ */
