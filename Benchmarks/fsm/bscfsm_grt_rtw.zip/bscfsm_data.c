/*
 * bscfsm_data.c
 *
 * Code generation for model "bscfsm".
 *
 * Model version              : 1.102
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Aug 28 13:59:13 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "bscfsm.h"
#include "bscfsm_private.h"

/* Block parameters (default storage) */
P_bscfsm_T bscfsm_P = {
  /* Expression: 1.0
   * Referenced by: '<S9>/Constant7'
   */
  1.0,

  /* Expression: 3.0
   * Referenced by: '<S9>/Constant1'
   */
  3.0,

  /* Expression: 2.0
   * Referenced by: '<S7>/Constant7'
   */
  2.0,

  /* Expression: 3.0
   * Referenced by: '<S7>/Constant1'
   */
  3.0,

  /* Expression: 0.0
   * Referenced by: '<S6>/Constant7'
   */
  0.0,

  /* Expression: 3.0
   * Referenced by: '<S6>/Constant1'
   */
  3.0,

  /* Expression: 0.0
   * Referenced by: '<S8>/Constant7'
   */
  0.0,

  /* Expression: 2.0
   * Referenced by: '<S8>/Constant1'
   */
  2.0,

  /* Expression: 1.0
   * Referenced by: '<S17>/Constant7'
   */
  1.0,

  /* Expression: 2.0
   * Referenced by: '<S17>/Constant1'
   */
  2.0,

  /* Expression: 0.0
   * Referenced by: '<S18>/Constant7'
   */
  0.0,

  /* Expression: 1.0
   * Referenced by: '<S16>/Constant7'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S1>/Unit Delay'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S1>/Unit Delay1'
   */
  0.0,

  /* Expression: 2
   * Referenced by: '<S15>/Constant6'
   */
  2.0,

  /* Computed Parameter: Constant16_Value
   * Referenced by: '<S13>/Constant16'
   */
  0,

  /* Computed Parameter: Constant17_Value
   * Referenced by: '<S13>/Constant17'
   */
  1,

  /* Computed Parameter: Constant18_Value
   * Referenced by: '<S13>/Constant18'
   */
  0,

  /* Computed Parameter: Constant3_Value
   * Referenced by: '<S11>/Constant3'
   */
  1,

  /* Computed Parameter: Constant4_Value
   * Referenced by: '<S11>/Constant4'
   */
  1,

  /* Computed Parameter: Constant5_Value
   * Referenced by: '<S11>/Constant5'
   */
  0,

  /* Computed Parameter: Constant10_Value
   * Referenced by: '<S10>/Constant10'
   */
  0,

  /* Computed Parameter: Constant11_Value
   * Referenced by: '<S10>/Constant11'
   */
  1,

  /* Computed Parameter: Constant9_Value
   * Referenced by: '<S10>/Constant9'
   */
  1,

  /* Computed Parameter: Constant1_Value_ol
   * Referenced by: '<S12>/Constant1'
   */
  0,

  /* Computed Parameter: Constant11_Value_k
   * Referenced by: '<S12>/Constant11'
   */
  0,

  /* Computed Parameter: Constant9_Value_b
   * Referenced by: '<S12>/Constant9'
   */
  1,

  /* Computed Parameter: Constant12_Value
   * Referenced by: '<S15>/Constant12'
   */
  1,

  /* Computed Parameter: Constant9_Value_g
   * Referenced by: '<S15>/Constant9'
   */
  0,

  /* Computed Parameter: UnitDelay2_InitialCondition
   * Referenced by: '<S1>/Unit Delay2'
   */
  1
};
