/*
 * regs_12B_data.c
 *
 * Code generation for model "regs_12B".
 *
 * Model version              : 1.55
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Aug 28 14:15:13 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "regs_12B.h"
#include "regs_12B_private.h"

/* Block parameters (default storage) */
P_regs_12B_T regs_12B_P = {
  /* Variable: dt
   * Referenced by:
   *   '<S9>/Constant4'
   *   '<S10>/Constant4'
   */
  0.01,

  /* Variable: transition_v
   * Referenced by: '<S12>/transition1'
   */
  { 0.0, 50.0, 90.0, 1000.0 },

  /* Variable: transition_y
   * Referenced by: '<S12>/transition1'
   */
  { 0.0, 0.0, 1.0, 1.0 },

  /* Expression: .5
   * Referenced by: '<S13>/Gain'
   */
  0.5,

  /* Expression: 0
   * Referenced by: '<S9>/Constant5'
   */
  0.0,

  /* Expression: .5
   * Referenced by: '<S16>/Gain'
   */
  0.5,

  /* Expression: 0
   * Referenced by: '<S10>/Constant5'
   */
  0.0,

  /* Expression: 2.5
   * Referenced by: '<S11>/one_o_Tau'
   */
  2.5,

  /* Expression: [120 185]
   * Referenced by: '<S10>/transition_bvr'
   */
  { 120.0, 185.0 },

  /* Expression: [15 20]
   * Referenced by: '<S10>/transition_bvr'
   */
  { 15.0, 20.0 },

  /* Expression: -9999
   * Referenced by: '<S10>/Constant6'
   */
  -9999.0,

  /* Expression: 9999
   * Referenced by: '<S10>/Constant7'
   */
  9999.0,

  /* Expression: 0
   * Referenced by: '<S16>/Unit Delay1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S16>/Unit Delay'
   */
  0.0,

  /* Expression: 5.0
   * Referenced by: '<S10>/Ki=5.0'
   */
  5.0,

  /* Expression: 2
   * Referenced by: '<S12>/omega_DR'
   */
  2.0,

  /* Expression: 1.0
   * Referenced by: '<S12>/zeta_DR'
   */
  1.0,

  /* Expression: 2
   * Referenced by: '<S12>/kts2fps1'
   */
  2.0,

  /* Expression: 1
   * Referenced by: '<S12>/Constant5'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S12>/Gain'
   */
  1.0,

  /* Expression: -1
   * Referenced by: '<S5>/Gain'
   */
  -1.0,

  /* Expression: 0.5
   * Referenced by: '<S8>/Gain'
   */
  0.5,

  /* Expression: -1
   * Referenced by: '<S5>/Gain1'
   */
  -1.0,

  /* Expression: 1
   * Referenced by: '<S9>/Saturation'
   */
  1.0,

  /* Expression: -1
   * Referenced by: '<S9>/Saturation'
   */
  -1.0,

  /* Expression: 1
   * Referenced by: '<S9>/Constant10'
   */
  1.0,

  /* Expression: 0.0
   * Referenced by: '<S9>/Constant3'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S9>/-8'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S9>/Memory'
   */
  0.0,

  /* Expression: -0.2
   * Referenced by: '<S9>/-0.2'
   */
  -0.2,

  /* Expression: 1.0
   * Referenced by: '<S9>/Kp=1.0'
   */
  1.0,

  /* Expression: -9999
   * Referenced by: '<S9>/Constant6'
   */
  -9999.0,

  /* Expression: 9999
   * Referenced by: '<S9>/Constant7'
   */
  9999.0,

  /* Expression: 0
   * Referenced by: '<S13>/Unit Delay1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S13>/Unit Delay'
   */
  0.0,

  /* Expression: 0.25
   * Referenced by: '<S9>/Ki=0.25'
   */
  0.25,

  /* Expression: false
   * Referenced by: '<S10>/Constant1'
   */
  0,

  /* Expression: false
   * Referenced by: '<S9>/Constant1'
   */
  0
};
