/*
 * regs_12B.c
 *
 * Code generation for model "regs_12B".
 *
 * Model version              : 1.55
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Sat Aug 28 14:15:13 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "regs_12B.h"
#include "regs_12B_private.h"

/* Block signals (default storage) */
B_regs_12B_T regs_12B_B;

/* Block states (default storage) */
DW_regs_12B_T regs_12B_DW;

/* External inputs (root inport signals with default storage) */
ExtU_regs_12B_T regs_12B_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_regs_12B_T regs_12B_Y;

/* Real-time model */
RT_MODEL_regs_12B_T regs_12B_M_;
RT_MODEL_regs_12B_T *const regs_12B_M = &regs_12B_M_;

/* Model output function */
static void regs_12B_output(void)
{
  /* local block i/o variables */
  real_T rtb_hcvdt_cmd_fcs_fps2;
  boolean_T rtb_RelationalOperator;
  real_T rtb_Switch;
  real_T rtb_Switch2;

  /* SignalConversion: '<S11>/Signal Conversion12' incorporates:
   *  Inport: '<Root>/lcv_fps_dps'
   */
  rtb_hcvdt_cmd_fcs_fps2 = regs_12B_U.lcv_fps_dps;

  /* Product: '<S11>/Product' incorporates:
   *  Constant: '<S11>/one_o_Tau'
   *  Inport: '<Root>/lcv_cmd_fcs_dps '
   *  Sum: '<S11>/Sum1'
   */
  rtb_hcvdt_cmd_fcs_fps2 = (regs_12B_U.lcv_cmd_fcs_dps - rtb_hcvdt_cmd_fcs_fps2)
    * regs_12B_P.one_o_Tau_Value;

  /* Outport: '<Root>/lcvdt_cmd_fcs_dps2' */
  regs_12B_Y.lcvdt_cmd_fcs_dps2 = rtb_hcvdt_cmd_fcs_fps2;

  /* Sum: '<S10>/Sum3' incorporates:
   *  Inport: '<Root>/mcv_cmd_fcs_dps'
   *  Inport: '<Root>/mcv_fcs_dps'
   */
  regs_12B_B.Sum3 = regs_12B_U.mcv_cmd_fcs_dps - regs_12B_U.mcv_fcs_dps;

  /* RelationalOperator: '<S18>/Relational Operator' incorporates:
   *  Constant: '<S10>/Constant6'
   *  Constant: '<S10>/Constant7'
   */
  rtb_RelationalOperator = (regs_12B_P.Constant7_Value <
    regs_12B_P.Constant6_Value);

  /* Switch: '<S18>/Switch1' incorporates:
   *  Constant: '<S10>/Constant6'
   *  Constant: '<S10>/Constant7'
   */
  if (rtb_RelationalOperator) {
    rtb_hcvdt_cmd_fcs_fps2 = regs_12B_P.Constant6_Value;
  } else {
    rtb_hcvdt_cmd_fcs_fps2 = regs_12B_P.Constant7_Value;
  }

  /* End of Switch: '<S18>/Switch1' */

  /* Switch: '<S16>/Switch' incorporates:
   *  Constant: '<S10>/Constant1'
   *  Constant: '<S10>/Constant4'
   *  Constant: '<S10>/Constant5'
   *  Gain: '<S16>/Gain'
   *  Product: '<S16>/Product'
   *  Sum: '<S16>/Sum'
   *  Sum: '<S16>/Sum1'
   *  UnitDelay: '<S16>/Unit Delay'
   *  UnitDelay: '<S16>/Unit Delay1'
   */
  if (regs_12B_P.Constant1_Value) {
    rtb_Switch = regs_12B_P.Constant5_Value_i;
  } else {
    rtb_Switch = (regs_12B_B.Sum3 + regs_12B_DW.UnitDelay_DSTATE) *
      regs_12B_P.Gain_Gain_f * regs_12B_P.dt + regs_12B_DW.UnitDelay1_DSTATE;
  }

  /* End of Switch: '<S16>/Switch' */

  /* Switch: '<S17>/Switch2' incorporates:
   *  RelationalOperator: '<S17>/LowerRelop1'
   *  Switch: '<S18>/Switch2'
   */
  if (rtb_Switch > rtb_hcvdt_cmd_fcs_fps2) {
    regs_12B_B.Switch2 = rtb_hcvdt_cmd_fcs_fps2;
  } else {
    if (rtb_RelationalOperator) {
      /* Switch: '<S18>/Switch2' incorporates:
       *  Constant: '<S10>/Constant7'
       */
      rtb_Switch2 = regs_12B_P.Constant7_Value;
    } else {
      /* Switch: '<S18>/Switch2' incorporates:
       *  Constant: '<S10>/Constant6'
       */
      rtb_Switch2 = regs_12B_P.Constant6_Value;
    }

    /* Switch: '<S17>/Switch' incorporates:
     *  RelationalOperator: '<S17>/UpperRelop'
     */
    if (rtb_Switch < rtb_Switch2) {
      regs_12B_B.Switch2 = rtb_Switch2;
    } else {
      regs_12B_B.Switch2 = rtb_Switch;
    }

    /* End of Switch: '<S17>/Switch' */
  }

  /* End of Switch: '<S17>/Switch2' */

  /* Sum: '<S10>/Sum9' incorporates:
   *  Gain: '<S10>/Ki=5.0'
   *  Inport: '<Root>/vtas_adc_kts'
   *  Lookup: '<S10>/transition_bvr'
   *  Product: '<S10>/Mult10'
   */
  rtb_hcvdt_cmd_fcs_fps2 = rt_Lookup(regs_12B_P.transition_bvr_XData, 2,
    regs_12B_U.vtas_adc_kts, regs_12B_P.transition_bvr_YData) * regs_12B_B.Sum3
    + regs_12B_P.Ki50_Gain * regs_12B_B.Switch2;

  /* Outport: '<Root>/mcvdt_cmd_fcs_dps2' */
  regs_12B_Y.mcvdt_cmd_fcs_dps2 = rtb_hcvdt_cmd_fcs_fps2;

  /* Math: '<S12>/Math Function' incorporates:
   *  Constant: '<S12>/omega_DR'
   */
  rtb_hcvdt_cmd_fcs_fps2 = regs_12B_P.omega_DR_Value * regs_12B_P.omega_DR_Value;

  /* Sum: '<S12>/Sum9' incorporates:
   *  Constant: '<S11>/one_o_Tau'
   *  Constant: '<S12>/omega_DR'
   *  Constant: '<S12>/zeta_DR'
   *  Gain: '<S12>/kts2fps1'
   *  Inport: '<Root>/beta_adc_deg'
   *  Inport: '<Root>/beta_dot'
   *  Inport: '<Root>/ncv_cmd_fcs_dps'
   *  Product: '<S12>/Product4'
   *  Product: '<S12>/Product5'
   *  Product: '<S12>/Product6'
   *  Product: '<S12>/Product7'
   *  Sum: '<S12>/Sum2'
   */
  rtb_Switch = (regs_12B_P.kts2fps1_Gain * regs_12B_P.zeta_DR_Value *
                regs_12B_P.omega_DR_Value - regs_12B_P.one_o_Tau_Value) *
    regs_12B_U.beta_dot + (regs_12B_U.ncv_cmd_fcs_dps * rtb_hcvdt_cmd_fcs_fps2 +
    rtb_hcvdt_cmd_fcs_fps2 * regs_12B_U.beta_adc_deg);

  /* Lookup: '<S12>/transition1' incorporates:
   *  Inport: '<Root>/vtas_adc_kts'
   */
  rtb_hcvdt_cmd_fcs_fps2 = rt_Lookup(regs_12B_P.transition_v, 4,
    regs_12B_U.vtas_adc_kts, regs_12B_P.transition_y);

  /* Sum: '<S12>/Sum11' incorporates:
   *  Constant: '<S12>/Constant5'
   *  Gain: '<S12>/Gain'
   *  Inport: '<Root>/ncv_cmd_fcs_dps'
   *  Inport: '<Root>/ncv_fcs_dps'
   *  Product: '<S12>/Product10'
   *  Product: '<S12>/Product9'
   *  Sum: '<S12>/Sum12'
   *  Sum: '<S12>/Sum4'
   */
  rtb_hcvdt_cmd_fcs_fps2 = (regs_12B_U.ncv_cmd_fcs_dps - regs_12B_U.ncv_fcs_dps)
    * regs_12B_P.Gain_Gain_j * (regs_12B_P.Constant5_Value_n -
    rtb_hcvdt_cmd_fcs_fps2) + rtb_Switch * rtb_hcvdt_cmd_fcs_fps2;

  /* Outport: '<Root>/ncvdt_cmd_fcs_dps2' */
  regs_12B_Y.ncvdt_cmd_fcs_dps2 = rtb_hcvdt_cmd_fcs_fps2;

  /* SignalConversion: '<S8>/Signal Conversion12' incorporates:
   *  Inport: '<Root>/xcv_cmd_fcs_fps'
   */
  rtb_hcvdt_cmd_fcs_fps2 = regs_12B_U.xcv_cmd_fcs_fps;

  /* Gain: '<S8>/Gain' incorporates:
   *  Gain: '<S5>/Gain'
   *  Inport: '<Root>/dcv_fcs_fps'
   *  Sum: '<S8>/Sum1'
   */
  rtb_hcvdt_cmd_fcs_fps2 = (rtb_hcvdt_cmd_fcs_fps2 - regs_12B_P.Gain_Gain_c *
    regs_12B_U.dcv_fcs_fps) * regs_12B_P.Gain_Gain_n;

  /* Outport: '<Root>/xcvdt_cmd_fcs_fps2' */
  regs_12B_Y.xcvdt_cmd_fcs_fps2 = rtb_hcvdt_cmd_fcs_fps2;

  /* SignalConversion: '<S9>/Signal Conversion9' incorporates:
   *  Inport: '<Root>/hcv_cmd_fcs_fps'
   */
  rtb_hcvdt_cmd_fcs_fps2 = regs_12B_U.hcv_cmd_fcs_fps;

  /* Sum: '<S9>/Sum1' incorporates:
   *  Gain: '<S5>/Gain1'
   *  Inport: '<Root>/zcv_fcs_fps'
   */
  rtb_hcvdt_cmd_fcs_fps2 -= regs_12B_P.Gain1_Gain * regs_12B_U.zcv_fcs_fps;

  /* Saturate: '<S9>/Saturation' */
  if (rtb_hcvdt_cmd_fcs_fps2 > regs_12B_P.Saturation_UpperSat) {
    rtb_hcvdt_cmd_fcs_fps2 = regs_12B_P.Saturation_UpperSat;
  } else {
    if (rtb_hcvdt_cmd_fcs_fps2 < regs_12B_P.Saturation_LowerSat) {
      rtb_hcvdt_cmd_fcs_fps2 = regs_12B_P.Saturation_LowerSat;
    }
  }

  /* End of Saturate: '<S9>/Saturation' */

  /* Product: '<S9>/Product9' incorporates:
   *  Constant: '<S9>/Constant10'
   *  Constant: '<S9>/Constant3'
   *  Sum: '<S9>/Sum7'
   */
  rtb_Switch = (regs_12B_P.Constant10_Value - regs_12B_P.Constant3_Value) *
    rtb_hcvdt_cmd_fcs_fps2;

  /* Memory: '<S9>/Memory' */
  rtb_hcvdt_cmd_fcs_fps2 = regs_12B_DW.Memory_PreviousInput;

  /* Sum: '<S9>/Sum8' incorporates:
   *  Constant: '<S9>/Constant3'
   *  Gain: '<S9>/-0.2'
   *  Gain: '<S9>/-8'
   *  Product: '<S9>/Product10'
   */
  regs_12B_B.Sum8 = regs_12B_P.Constant3_Value * rtb_hcvdt_cmd_fcs_fps2 *
    regs_12B_P.u2_Gain + regs_12B_P.u_Gain * rtb_Switch;

  /* RelationalOperator: '<S15>/Relational Operator' incorporates:
   *  Constant: '<S9>/Constant6'
   *  Constant: '<S9>/Constant7'
   */
  rtb_RelationalOperator = (regs_12B_P.Constant7_Value_h <
    regs_12B_P.Constant6_Value_d);

  /* Switch: '<S15>/Switch1' incorporates:
   *  Constant: '<S9>/Constant6'
   *  Constant: '<S9>/Constant7'
   */
  if (rtb_RelationalOperator) {
    rtb_hcvdt_cmd_fcs_fps2 = regs_12B_P.Constant6_Value_d;
  } else {
    rtb_hcvdt_cmd_fcs_fps2 = regs_12B_P.Constant7_Value_h;
  }

  /* End of Switch: '<S15>/Switch1' */

  /* Switch: '<S13>/Switch' incorporates:
   *  Constant: '<S9>/Constant1'
   *  Constant: '<S9>/Constant4'
   *  Constant: '<S9>/Constant5'
   *  Gain: '<S13>/Gain'
   *  Product: '<S13>/Product'
   *  Sum: '<S13>/Sum'
   *  Sum: '<S13>/Sum1'
   *  UnitDelay: '<S13>/Unit Delay'
   *  UnitDelay: '<S13>/Unit Delay1'
   */
  if (regs_12B_P.Constant1_Value_i) {
    rtb_Switch = regs_12B_P.Constant5_Value;
  } else {
    rtb_Switch = (regs_12B_B.Sum8 + regs_12B_DW.UnitDelay_DSTATE_a) *
      regs_12B_P.Gain_Gain * regs_12B_P.dt + regs_12B_DW.UnitDelay1_DSTATE_c;
  }

  /* End of Switch: '<S13>/Switch' */

  /* Switch: '<S14>/Switch2' incorporates:
   *  RelationalOperator: '<S14>/LowerRelop1'
   *  Switch: '<S15>/Switch2'
   */
  if (rtb_Switch > rtb_hcvdt_cmd_fcs_fps2) {
    regs_12B_B.Switch2_c = rtb_hcvdt_cmd_fcs_fps2;
  } else {
    if (rtb_RelationalOperator) {
      /* Switch: '<S15>/Switch2' incorporates:
       *  Constant: '<S9>/Constant7'
       */
      rtb_Switch2 = regs_12B_P.Constant7_Value_h;
    } else {
      /* Switch: '<S15>/Switch2' incorporates:
       *  Constant: '<S9>/Constant6'
       */
      rtb_Switch2 = regs_12B_P.Constant6_Value_d;
    }

    /* Switch: '<S14>/Switch' incorporates:
     *  RelationalOperator: '<S14>/UpperRelop'
     */
    if (rtb_Switch < rtb_Switch2) {
      regs_12B_B.Switch2_c = rtb_Switch2;
    } else {
      regs_12B_B.Switch2_c = rtb_Switch;
    }

    /* End of Switch: '<S14>/Switch' */
  }

  /* End of Switch: '<S14>/Switch2' */

  /* Sum: '<S9>/Sum2' incorporates:
   *  Gain: '<S9>/Ki=0.25'
   *  Gain: '<S9>/Kp=1.0'
   */
  rtb_hcvdt_cmd_fcs_fps2 = regs_12B_P.Kp10_Gain * regs_12B_B.Sum8 +
    regs_12B_P.Ki025_Gain * regs_12B_B.Switch2_c;

  /* Outport: '<Root>/hcvdt_cmd_fcs_fps2' */
  regs_12B_Y.hcvdt_cmd_fcs_fps2 = rtb_hcvdt_cmd_fcs_fps2;
}

/* Model update function */
static void regs_12B_update(void)
{
  /* Update for UnitDelay: '<S16>/Unit Delay1' */
  regs_12B_DW.UnitDelay1_DSTATE = regs_12B_B.Switch2;

  /* Update for UnitDelay: '<S16>/Unit Delay' */
  regs_12B_DW.UnitDelay_DSTATE = regs_12B_B.Sum3;

  /* Update for Memory: '<S9>/Memory' */
  regs_12B_DW.Memory_PreviousInput = regs_12B_B.Switch2_c;

  /* Update for UnitDelay: '<S13>/Unit Delay1' */
  regs_12B_DW.UnitDelay1_DSTATE_c = regs_12B_B.Switch2_c;

  /* Update for UnitDelay: '<S13>/Unit Delay' */
  regs_12B_DW.UnitDelay_DSTATE_a = regs_12B_B.Sum8;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++regs_12B_M->Timing.clockTick0)) {
    ++regs_12B_M->Timing.clockTickH0;
  }

  regs_12B_M->Timing.t[0] = regs_12B_M->Timing.clockTick0 *
    regs_12B_M->Timing.stepSize0 + regs_12B_M->Timing.clockTickH0 *
    regs_12B_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
static void regs_12B_initialize(void)
{
  /* InitializeConditions for UnitDelay: '<S16>/Unit Delay1' */
  regs_12B_DW.UnitDelay1_DSTATE = regs_12B_P.UnitDelay1_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S16>/Unit Delay' */
  regs_12B_DW.UnitDelay_DSTATE = regs_12B_P.UnitDelay_InitialCondition;

  /* InitializeConditions for Memory: '<S9>/Memory' */
  regs_12B_DW.Memory_PreviousInput = regs_12B_P.Memory_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S13>/Unit Delay1' */
  regs_12B_DW.UnitDelay1_DSTATE_c = regs_12B_P.UnitDelay1_InitialCondition_i;

  /* InitializeConditions for UnitDelay: '<S13>/Unit Delay' */
  regs_12B_DW.UnitDelay_DSTATE_a = regs_12B_P.UnitDelay_InitialCondition_o;
}

/* Model terminate function */
static void regs_12B_terminate(void)
{
  /* (no terminate code required) */
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  regs_12B_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  regs_12B_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  regs_12B_initialize();
}

void MdlTerminate(void)
{
  regs_12B_terminate();
}

/* Registration function */
RT_MODEL_regs_12B_T *regs_12B(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)regs_12B_M, 0,
                sizeof(RT_MODEL_regs_12B_T));

  /* Initialize timing info */
  {
    int_T *mdlTsMap = regs_12B_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    regs_12B_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    regs_12B_M->Timing.sampleTimes = (&regs_12B_M->Timing.sampleTimesArray[0]);
    regs_12B_M->Timing.offsetTimes = (&regs_12B_M->Timing.offsetTimesArray[0]);

    /* task periods */
    regs_12B_M->Timing.sampleTimes[0] = (0.01);

    /* task offsets */
    regs_12B_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(regs_12B_M, &regs_12B_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = regs_12B_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    regs_12B_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(regs_12B_M, 10.0);
  regs_12B_M->Timing.stepSize0 = 0.01;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    regs_12B_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(regs_12B_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(regs_12B_M->rtwLogInfo, (NULL));
    rtliSetLogT(regs_12B_M->rtwLogInfo, "tout");
    rtliSetLogX(regs_12B_M->rtwLogInfo, "");
    rtliSetLogXFinal(regs_12B_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(regs_12B_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(regs_12B_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(regs_12B_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(regs_12B_M->rtwLogInfo, 1);

    /*
     * Set pointers to the data and signal info for each output
     */
    {
      static void * rt_LoggedOutputSignalPtrs[] = {
        &regs_12B_Y.lcvdt_cmd_fcs_dps2,
        &regs_12B_Y.mcvdt_cmd_fcs_dps2,
        &regs_12B_Y.ncvdt_cmd_fcs_dps2,
        &regs_12B_Y.xcvdt_cmd_fcs_fps2,
        &regs_12B_Y.hcvdt_cmd_fcs_fps2
      };

      rtliSetLogYSignalPtrs(regs_12B_M->rtwLogInfo, ((LogSignalPtrsType)
        rt_LoggedOutputSignalPtrs));
    }

    {
      static int_T rt_LoggedOutputWidths[] = {
        1,
        1,
        1,
        1,
        1
      };

      static int_T rt_LoggedOutputNumDimensions[] = {
        1,
        1,
        1,
        1,
        1
      };

      static int_T rt_LoggedOutputDimensions[] = {
        1,
        1,
        1,
        1,
        1
      };

      static boolean_T rt_LoggedOutputIsVarDims[] = {
        0,
        0,
        0,
        0,
        0
      };

      static void* rt_LoggedCurrentSignalDimensions[] = {
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL)
      };

      static int_T rt_LoggedCurrentSignalDimensionsSize[] = {
        4,
        4,
        4,
        4,
        4
      };

      static BuiltInDTypeId rt_LoggedOutputDataTypeIds[] = {
        SS_DOUBLE,
        SS_DOUBLE,
        SS_DOUBLE,
        SS_DOUBLE,
        SS_DOUBLE
      };

      static int_T rt_LoggedOutputComplexSignals[] = {
        0,
        0,
        0,
        0,
        0
      };

      static RTWPreprocessingFcnPtr rt_LoggingPreprocessingFcnPtrs[] = {
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL)
      };

      static const char_T *rt_LoggedOutputLabels[] = {
        "lcvdt_cmd_fcs_dps2",
        "mcvdt_cmd_fcs_dps2",
        "ncvdt_cmd_fcs_dps2",
        "xcvdt_cmd_fcs_fps2",
        "hcvdt_cmd_fcs_fps2" };

      static const char_T *rt_LoggedOutputBlockNames[] = {
        "regs_12B/lcvdt_cmd_fcs_dps2",
        "regs_12B/mcvdt_cmd_fcs_dps2",
        "regs_12B/ncvdt_cmd_fcs_dps2",
        "regs_12B/xcvdt_cmd_fcs_fps2",
        "regs_12B/hcvdt_cmd_fcs_fps2" };

      static RTWLogDataTypeConvert rt_RTWLogDataTypeConvert[] = {
        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 }
      };

      static RTWLogSignalInfo rt_LoggedOutputSignalInfo[] = {
        {
          5,
          rt_LoggedOutputWidths,
          rt_LoggedOutputNumDimensions,
          rt_LoggedOutputDimensions,
          rt_LoggedOutputIsVarDims,
          rt_LoggedCurrentSignalDimensions,
          rt_LoggedCurrentSignalDimensionsSize,
          rt_LoggedOutputDataTypeIds,
          rt_LoggedOutputComplexSignals,
          (NULL),
          rt_LoggingPreprocessingFcnPtrs,

          { rt_LoggedOutputLabels },
          (NULL),
          (NULL),
          (NULL),

          { rt_LoggedOutputBlockNames },

          { (NULL) },
          (NULL),
          rt_RTWLogDataTypeConvert
        }
      };

      rtliSetLogYSignalInfo(regs_12B_M->rtwLogInfo, rt_LoggedOutputSignalInfo);

      /* set currSigDims field */
      rt_LoggedCurrentSignalDimensions[0] = &rt_LoggedOutputWidths[0];
      rt_LoggedCurrentSignalDimensions[1] = &rt_LoggedOutputWidths[1];
      rt_LoggedCurrentSignalDimensions[2] = &rt_LoggedOutputWidths[2];
      rt_LoggedCurrentSignalDimensions[3] = &rt_LoggedOutputWidths[3];
      rt_LoggedCurrentSignalDimensions[4] = &rt_LoggedOutputWidths[4];
    }

    rtliSetLogY(regs_12B_M->rtwLogInfo, "yout");
  }

  regs_12B_M->solverInfoPtr = (&regs_12B_M->solverInfo);
  regs_12B_M->Timing.stepSize = (0.01);
  rtsiSetFixedStepSize(&regs_12B_M->solverInfo, 0.01);
  rtsiSetSolverMode(&regs_12B_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  regs_12B_M->blockIO = ((void *) &regs_12B_B);
  (void) memset(((void *) &regs_12B_B), 0,
                sizeof(B_regs_12B_T));

  /* parameters */
  regs_12B_M->defaultParam = ((real_T *)&regs_12B_P);

  /* states (dwork) */
  regs_12B_M->dwork = ((void *) &regs_12B_DW);
  (void) memset((void *)&regs_12B_DW, 0,
                sizeof(DW_regs_12B_T));

  /* external inputs */
  regs_12B_M->inputs = (((void*)&regs_12B_U));
  (void)memset(&regs_12B_U, 0, sizeof(ExtU_regs_12B_T));

  /* external outputs */
  regs_12B_M->outputs = (&regs_12B_Y);
  (void) memset((void *)&regs_12B_Y, 0,
                sizeof(ExtY_regs_12B_T));

  /* Initialize Sizes */
  regs_12B_M->Sizes.numContStates = (0);/* Number of continuous states */
  regs_12B_M->Sizes.numY = (5);        /* Number of model outputs */
  regs_12B_M->Sizes.numU = (16);       /* Number of model inputs */
  regs_12B_M->Sizes.sysDirFeedThru = (1);/* The model is direct feedthrough */
  regs_12B_M->Sizes.numSampTimes = (1);/* Number of sample times */
  regs_12B_M->Sizes.numBlocks = (106); /* Number of blocks */
  regs_12B_M->Sizes.numBlockIO = (4);  /* Number of block outputs */
  regs_12B_M->Sizes.numBlockPrms = (46);/* Sum of parameter "widths" */
  return regs_12B_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
