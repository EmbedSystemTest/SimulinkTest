/*
 * NLGuidance.h
 *
 * Code generation for model "NLGuidance".
 *
 * Model version              : 1.72
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Fri Aug 27 10:10:14 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_NLGuidance_h_
#define RTW_HEADER_NLGuidance_h_
#include <stddef.h>
#include <math.h>
#include <string.h>
#include <float.h>
#ifndef NLGuidance_COMMON_INCLUDES_
# define NLGuidance_COMMON_INCLUDES_
#include <stdlib.h>
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                                 /* NLGuidance_COMMON_INCLUDES_ */

#include "NLGuidance_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               (&(rtm)->Timing.taskTime0)
#endif

/* Block states (default storage) for system '<Root>' */
typedef struct {
  struct {
    void *LoggedData;
  } ToWorkspace_PWORK;                 /* '<S3>/To Workspace' */

  struct {
    void *LoggedData;
  } ToWorkspace1_PWORK;                /* '<S3>/To Workspace1' */

  struct {
    void *LoggedData;
  } ToWorkspace1_PWORK_h;              /* '<S2>/To Workspace1' */

  struct {
    void *LoggedData;
  } ToWorkspace2_PWORK;                /* '<S2>/To Workspace2' */
} DW_NLGuidance_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T Xtarg[3];                     /* '<Root>/Xtarg' */
  real_T Xv[3];                        /* '<Root>/Xv' */
  real_T Vv[3];                        /* '<Root>/Vv' */
  real_T Vt[3];                        /* '<Root>/Vt' */
  real_T r;                            /* '<Root>/r' */
} ExtU_NLGuidance_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T yout[3];                      /* '<Root>/yout' */
} ExtY_NLGuidance_T;

/* Parameters (default storage) */
struct P_NLGuidance_T_ {
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S8>/Constant1'
                                        */
  real_T Gain_Gain;                    /* Expression: -1
                                        * Referenced by: '<S2>/Gain'
                                        */
  real_T Constant1_Value_m;            /* Expression: 0
                                        * Referenced by: '<S9>/Constant1'
                                        */
  real_T Gain2_Gain;                   /* Expression: -1
                                        * Referenced by: '<S15>/Gain2'
                                        */
  real_T Constant1_Value_k;            /* Expression: 0
                                        * Referenced by: '<S3>/Constant1'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S1>/Constant2'
                                        */
  real_T Constant1_Value_i;            /* Expression: 0
                                        * Referenced by: '<S1>/Constant1'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_NLGuidance_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_NLGuidance_T NLGuidance_P;

/* Block states (default storage) */
extern DW_NLGuidance_T NLGuidance_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_NLGuidance_T NLGuidance_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_NLGuidance_T NLGuidance_Y;

/* Model entry point functions */
extern void NLGuidance_initialize(void);
extern void NLGuidance_step(void);
extern void NLGuidance_terminate(void);

/* Real-time Model object */
extern RT_MODEL_NLGuidance_T *const NLGuidance_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'NLGuidance'
 * '<S1>'   : 'NLGuidance/NLGuidance'
 * '<S2>'   : 'NLGuidance/NLGuidance/Inner'
 * '<S3>'   : 'NLGuidance/NLGuidance/Outer'
 * '<S4>'   : 'NLGuidance/NLGuidance/norm1'
 * '<S5>'   : 'NLGuidance/NLGuidance/norm2'
 * '<S6>'   : 'NLGuidance/NLGuidance/Inner/Act1'
 * '<S7>'   : 'NLGuidance/NLGuidance/Inner/Act2'
 * '<S8>'   : 'NLGuidance/NLGuidance/Inner/Arg1'
 * '<S9>'   : 'NLGuidance/NLGuidance/Inner/Arg2'
 * '<S10>'  : 'NLGuidance/NLGuidance/Inner/norm'
 * '<S11>'  : 'NLGuidance/NLGuidance/Inner/norm1'
 * '<S12>'  : 'NLGuidance/NLGuidance/Outer/CCW'
 * '<S13>'  : 'NLGuidance/NLGuidance/Outer/CW'
 * '<S14>'  : 'NLGuidance/NLGuidance/Outer/cross'
 * '<S15>'  : 'NLGuidance/NLGuidance/Outer/r_computation'
 * '<S16>'  : 'NLGuidance/NLGuidance/Outer/cross/Subsystem1'
 * '<S17>'  : 'NLGuidance/NLGuidance/Outer/cross/Subsystem2'
 */
#endif                                 /* RTW_HEADER_NLGuidance_h_ */
