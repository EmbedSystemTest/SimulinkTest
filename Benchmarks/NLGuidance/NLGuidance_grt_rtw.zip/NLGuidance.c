/*
 * NLGuidance.c
 *
 * Code generation for model "NLGuidance".
 *
 * Model version              : 1.72
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Fri Aug 27 10:10:14 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "NLGuidance.h"
#include "NLGuidance_private.h"

/* Block states (default storage) */
DW_NLGuidance_T NLGuidance_DW;

/* External inputs (root inport signals with default storage) */
ExtU_NLGuidance_T NLGuidance_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_NLGuidance_T NLGuidance_Y;

/* Real-time model */
RT_MODEL_NLGuidance_T NLGuidance_M_;
RT_MODEL_NLGuidance_T *const NLGuidance_M = &NLGuidance_M_;

/*
 * Output and update for action system:
 *    '<S3>/CW'
 *    '<S3>/CCW'
 */
void NLGuidance_CW(const real_T rtu_Xap1[3], real_T rty_yout[3])
{
  /* Inport: '<S13>/Xap1' */
  rty_yout[0] = rtu_Xap1[0];
  rty_yout[1] = rtu_Xap1[1];
  rty_yout[2] = rtu_Xap1[2];
}

/* Model step function */
void NLGuidance_step(void)
{
  /* local block i/o variables */
  real_T rtb_Sum4[3];
  real_T rtb_Sum8[3];
  real_T rtb_TmpSignalConversionAtToWork[3];
  real_T rtb_TmpSignalConversionAtToWo_h[3];
  real_T rtb_MathFunction1_m;
  real_T rtb_MathFunction1;
  real_T rtb_Sum2;
  real_T rtb_XrDotVv;
  real_T rtb_Xr_0;
  real_T rtb_Xr;
  real_T rtb_Xr_idx_0;
  real_T rtb_Xr_idx_1;
  real_T rtb_MathFunction_idx_0;
  real_T rtb_MathFunction_idx_1;

  /* Sum: '<S1>/Sum' incorporates:
   *  Inport: '<Root>/Xtarg'
   *  Inport: '<Root>/Xv'
   */
  rtb_Xr = NLGuidance_U.Xtarg[0] - NLGuidance_U.Xv[0];

  /* Math: '<S4>/Math Function' */
  rtb_MathFunction_idx_0 = rtb_Xr * rtb_Xr;

  /* Sum: '<S1>/Sum' incorporates:
   *  Inport: '<Root>/Xtarg'
   *  Inport: '<Root>/Xv'
   */
  rtb_Xr_idx_0 = rtb_Xr;
  rtb_Xr = NLGuidance_U.Xtarg[1] - NLGuidance_U.Xv[1];

  /* Math: '<S4>/Math Function' */
  rtb_MathFunction_idx_1 = rtb_Xr * rtb_Xr;

  /* Sum: '<S1>/Sum' incorporates:
   *  Inport: '<Root>/Xtarg'
   *  Inport: '<Root>/Xv'
   */
  rtb_Xr_idx_1 = rtb_Xr;
  rtb_Xr = NLGuidance_U.Xtarg[2] - NLGuidance_U.Xv[2];

  /* Sum: '<S4>/Sum of Elements' incorporates:
   *  Math: '<S4>/Math Function'
   */
  rtb_MathFunction1_m = (rtb_MathFunction_idx_0 + rtb_MathFunction_idx_1) +
    rtb_Xr * rtb_Xr;

  /* Math: '<S4>/Math Function1'
   *
   * About '<S4>/Math Function1':
   *  Operator: sqrt
   */
  if (rtb_MathFunction1_m < 0.0) {
    rtb_MathFunction1 = -sqrt(fabs(rtb_MathFunction1_m));
  } else {
    rtb_MathFunction1 = sqrt(rtb_MathFunction1_m);
  }

  /* End of Math: '<S4>/Math Function1' */

  /* Outputs for IfAction SubSystem: '<S1>/Outer' incorporates:
   *  ActionPort: '<S3>/Action Port'
   */
  /* If: '<S1>/If' incorporates:
   *  Math: '<S15>/Math Function2'
   *  Math: '<S1>/Math Function1'
   *  Math: '<S1>/Math Function3'
   */
  rtb_XrDotVv = rtb_MathFunction1 * rtb_MathFunction1;

  /* End of Outputs for SubSystem: '<S1>/Outer' */

  /* Sum: '<S1>/Sum2' incorporates:
   *  Inport: '<Root>/r'
   *  Math: '<S1>/Math Function3'
   *  Math: '<S1>/Math Function4'
   */
  rtb_Sum2 = rtb_XrDotVv - NLGuidance_U.r * NLGuidance_U.r;

  /* Sum: '<S5>/Sum of Elements' incorporates:
   *  Inport: '<Root>/Vv'
   *  Math: '<S5>/Math Function'
   */
  rtb_MathFunction1_m = (NLGuidance_U.Vv[0] * NLGuidance_U.Vv[0] +
    NLGuidance_U.Vv[1] * NLGuidance_U.Vv[1]) + NLGuidance_U.Vv[2] *
    NLGuidance_U.Vv[2];

  /* DotProduct: '<S1>/Dot Product' incorporates:
   *  Inport: '<Root>/Vv'
   */
  rtb_Xr_0 = (rtb_Xr_idx_0 * NLGuidance_U.Vv[0] + rtb_Xr_idx_1 *
              NLGuidance_U.Vv[1]) + rtb_Xr * NLGuidance_U.Vv[2];

  /* Math: '<S5>/Math Function1'
   *
   * About '<S5>/Math Function1':
   *  Operator: sqrt
   */
  if (rtb_MathFunction1_m < 0.0) {
    rtb_MathFunction1_m = -sqrt(fabs(rtb_MathFunction1_m));
  } else {
    rtb_MathFunction1_m = sqrt(rtb_MathFunction1_m);
  }

  /* End of Math: '<S5>/Math Function1' */

  /* Sum: '<S1>/Sum1' incorporates:
   *  DotProduct: '<S1>/Dot Product'
   *  Math: '<S1>/Math Function'
   *  Math: '<S1>/Math Function2'
   *  Product: '<S1>/Product'
   */
  rtb_MathFunction1_m = rtb_XrDotVv * (rtb_MathFunction1_m * rtb_MathFunction1_m)
    - rtb_Xr_0 * rtb_Xr_0;

  /* If: '<S1>/If' incorporates:
   *  Constant: '<S1>/Constant1'
   *  Constant: '<S1>/Constant2'
   *  Logic: '<S1>/Logical Operator'
   *  RelationalOperator: '<S1>/Relational Operator'
   *  RelationalOperator: '<S1>/Relational Operator1'
   */
  if ((rtb_Sum2 <= NLGuidance_P.Constant2_Value) || (rtb_MathFunction1_m <=
       NLGuidance_P.Constant1_Value_i)) {
    /* Outputs for IfAction SubSystem: '<S1>/Inner' incorporates:
     *  ActionPort: '<S2>/Action Port'
     */
    /* Product: '<S2>/Divide' incorporates:
     *  Inport: '<Root>/r'
     */
    rtb_XrDotVv = NLGuidance_U.r / rtb_MathFunction1;

    /* SignalConversion generated from: '<S2>/To Workspace1' incorporates:
     *  Constant: '<S8>/Constant1'
     *  Inport: '<Root>/Xtarg'
     *  Product: '<S8>/Product'
     *  Product: '<S8>/Product1'
     *  Sum: '<S8>/Sum'
     *  Sum: '<S8>/Sum1'
     */
    rtb_TmpSignalConversionAtToWork[0] = rtb_XrDotVv * rtb_Xr_idx_0 +
      NLGuidance_U.Xtarg[0];
    rtb_TmpSignalConversionAtToWork[1] = rtb_Xr_idx_1 * rtb_XrDotVv +
      NLGuidance_U.Xtarg[1];
    rtb_TmpSignalConversionAtToWork[2] = NLGuidance_P.Constant1_Value;

    /* ToWorkspace: '<S2>/To Workspace1' */
    rt_UpdateLogVar((LogVar *)(LogVar*)
                    (NLGuidance_DW.ToWorkspace1_PWORK_h.LoggedData),
                    &rtb_TmpSignalConversionAtToWork[0], 0);

    /* Gain: '<S2>/Gain' */
    rtb_XrDotVv *= NLGuidance_P.Gain_Gain;

    /* SignalConversion generated from: '<S2>/To Workspace2' incorporates:
     *  Inport: '<Root>/Xtarg'
     *  Product: '<S9>/Product'
     *  Sum: '<S9>/Sum'
     */
    rtb_TmpSignalConversionAtToWo_h[0] = rtb_XrDotVv * rtb_Xr_idx_0 +
      NLGuidance_U.Xtarg[0];

    /* Product: '<S9>/Product1' */
    rtb_XrDotVv *= rtb_Xr_idx_1;

    /* SignalConversion generated from: '<S2>/To Workspace2' incorporates:
     *  Constant: '<S9>/Constant1'
     *  Inport: '<Root>/Xtarg'
     *  Sum: '<S9>/Sum1'
     */
    rtb_TmpSignalConversionAtToWo_h[1] = NLGuidance_U.Xtarg[1] + rtb_XrDotVv;
    rtb_TmpSignalConversionAtToWo_h[2] = NLGuidance_P.Constant1_Value_m;

    /* ToWorkspace: '<S2>/To Workspace2' */
    rt_UpdateLogVar((LogVar *)(LogVar*)
                    (NLGuidance_DW.ToWorkspace2_PWORK.LoggedData),
                    &rtb_TmpSignalConversionAtToWo_h[0], 0);

    /* Sum: '<S8>/Sum2' incorporates:
     *  Inport: '<Root>/Xv'
     *  Math: '<S10>/Math Function'
     */
    rtb_Xr = rtb_TmpSignalConversionAtToWork[0] - NLGuidance_U.Xv[0];
    rtb_Xr_idx_0 = rtb_Xr * rtb_Xr;
    rtb_Xr = rtb_TmpSignalConversionAtToWork[1] - NLGuidance_U.Xv[1];
    rtb_Xr_idx_1 = rtb_Xr * rtb_Xr;
    rtb_Xr = rtb_TmpSignalConversionAtToWork[2] - NLGuidance_U.Xv[2];

    /* Math: '<S10>/Math Function' */
    rtb_Xr *= rtb_Xr;

    /* Sum: '<S10>/Sum of Elements' */
    rtb_Sum2 = (rtb_Xr_idx_0 + rtb_Xr_idx_1) + rtb_Xr;

    /* Math: '<S10>/Math Function1'
     *
     * About '<S10>/Math Function1':
     *  Operator: sqrt
     */
    if (rtb_Sum2 < 0.0) {
      rtb_Sum2 = -sqrt(fabs(rtb_Sum2));
    } else {
      rtb_Sum2 = sqrt(rtb_Sum2);
    }

    /* End of Math: '<S10>/Math Function1' */

    /* Sum: '<S9>/Sum2' incorporates:
     *  Inport: '<Root>/Xv'
     *  Math: '<S11>/Math Function'
     */
    rtb_Xr = rtb_TmpSignalConversionAtToWo_h[0] - NLGuidance_U.Xv[0];
    rtb_Xr_idx_0 = rtb_Xr * rtb_Xr;
    rtb_Xr = rtb_TmpSignalConversionAtToWo_h[1] - NLGuidance_U.Xv[1];
    rtb_Xr_idx_1 = rtb_Xr * rtb_Xr;
    rtb_Xr = rtb_TmpSignalConversionAtToWo_h[2] - NLGuidance_U.Xv[2];

    /* Math: '<S11>/Math Function' */
    rtb_Xr *= rtb_Xr;

    /* Sum: '<S11>/Sum of Elements' */
    rtb_MathFunction1 = (rtb_Xr_idx_0 + rtb_Xr_idx_1) + rtb_Xr;

    /* Math: '<S11>/Math Function1'
     *
     * About '<S11>/Math Function1':
     *  Operator: sqrt
     */
    if (rtb_MathFunction1 < 0.0) {
      rtb_MathFunction1 = -sqrt(fabs(rtb_MathFunction1));
    } else {
      rtb_MathFunction1 = sqrt(rtb_MathFunction1);
    }

    /* End of Math: '<S11>/Math Function1' */

    /* If: '<S2>/If' incorporates:
     *  RelationalOperator: '<S2>/Relational Operator1'
     */
    if (rtb_Sum2 < rtb_MathFunction1) {
      /* Outputs for IfAction SubSystem: '<S2>/Act1' incorporates:
       *  ActionPort: '<S6>/Action Port'
       */
      /* Outport: '<Root>/yout' incorporates:
       *  Inport: '<S6>/cmd1'
       */
      NLGuidance_Y.yout[0] = rtb_TmpSignalConversionAtToWork[0];
      NLGuidance_Y.yout[1] = rtb_TmpSignalConversionAtToWork[1];
      NLGuidance_Y.yout[2] = rtb_TmpSignalConversionAtToWork[2];

      /* End of Outputs for SubSystem: '<S2>/Act1' */
    } else {
      /* Outputs for IfAction SubSystem: '<S2>/Act2' incorporates:
       *  ActionPort: '<S7>/Action Port'
       */
      /* Outport: '<Root>/yout' incorporates:
       *  Inport: '<S7>/cmd2'
       */
      NLGuidance_Y.yout[0] = rtb_TmpSignalConversionAtToWo_h[0];
      NLGuidance_Y.yout[1] = rtb_TmpSignalConversionAtToWo_h[1];
      NLGuidance_Y.yout[2] = rtb_TmpSignalConversionAtToWo_h[2];

      /* End of Outputs for SubSystem: '<S2>/Act2' */
    }

    /* End of If: '<S2>/If' */
    /* End of Outputs for SubSystem: '<S1>/Inner' */
  } else {
    /* Outputs for IfAction SubSystem: '<S1>/Outer' incorporates:
     *  ActionPort: '<S3>/Action Port'
     */
    /* Sqrt: '<S3>/Sqrt' incorporates:
     *  Product: '<S3>/Divide1'
     */
    rtb_Sum2 = sqrt(rtb_Sum2 / rtb_MathFunction1_m);

    /* Product: '<S15>/Product7' incorporates:
     *  Inport: '<Root>/Vv'
     */
    rtb_MathFunction_idx_0 = rtb_Sum2 * NLGuidance_U.Vv[0];
    rtb_MathFunction_idx_1 = rtb_Sum2 * NLGuidance_U.Vv[1];
    rtb_MathFunction1_m = rtb_Sum2 * NLGuidance_U.Vv[2];

    /* Product: '<S15>/Divide4' */
    rtb_MathFunction1 = 1.0 / rtb_XrDotVv;

    /* Product: '<S15>/Product2' incorporates:
     *  DotProduct: '<S1>/Dot Product'
     */
    rtb_Sum2 *= rtb_Xr_0;

    /* Sum: '<S15>/Sum5' incorporates:
     *  Inport: '<Root>/r'
     */
    rtb_XrDotVv = rtb_Sum2 - NLGuidance_U.r;

    /* Sum: '<S3>/Sum4' incorporates:
     *  Inport: '<Root>/Xv'
     *  Inport: '<Root>/r'
     *  Product: '<S15>/Product4'
     *  Product: '<S15>/Product6'
     *  Product: '<S15>/Product9'
     *  Sum: '<S15>/Sum1'
     *  Sum: '<S15>/Sum6'
     */
    rtb_Sum4[0] = ((rtb_XrDotVv * rtb_Xr_idx_0 * rtb_MathFunction1 -
                    rtb_MathFunction_idx_0) * NLGuidance_U.r + rtb_Xr_idx_0) +
      NLGuidance_U.Xv[0];
    rtb_Sum4[1] = ((rtb_XrDotVv * rtb_Xr_idx_1 * rtb_MathFunction1 -
                    rtb_MathFunction_idx_1) * NLGuidance_U.r + rtb_Xr_idx_1) +
      NLGuidance_U.Xv[1];
    rtb_Sum4[2] = ((rtb_XrDotVv * rtb_Xr * rtb_MathFunction1 -
                    rtb_MathFunction1_m) * NLGuidance_U.r + rtb_Xr) +
      NLGuidance_U.Xv[2];

    /* ToWorkspace: '<S3>/To Workspace' */
    rt_UpdateLogVar((LogVar *)(LogVar*)
                    (NLGuidance_DW.ToWorkspace_PWORK.LoggedData), &rtb_Sum4[0],
                    0);

    /* Sum: '<S15>/Sum4' incorporates:
     *  Inport: '<Root>/r'
     */
    rtb_XrDotVv = NLGuidance_U.r + rtb_Sum2;

    /* Gain: '<S15>/Gain2' */
    rtb_MathFunction1 *= NLGuidance_P.Gain2_Gain;

    /* Sum: '<S3>/Sum8' incorporates:
     *  Inport: '<Root>/Xv'
     *  Inport: '<Root>/r'
     *  Product: '<S15>/Product3'
     *  Product: '<S15>/Product5'
     *  Product: '<S15>/Product8'
     *  Sum: '<S15>/Sum'
     *  Sum: '<S15>/Sum7'
     */
    rtb_Sum8[0] = ((rtb_XrDotVv * rtb_Xr_idx_0 * rtb_MathFunction1 +
                    rtb_MathFunction_idx_0) * NLGuidance_U.r + rtb_Xr_idx_0) +
      NLGuidance_U.Xv[0];

    /* Sum: '<S15>/Sum7' incorporates:
     *  Inport: '<Root>/r'
     *  Product: '<S15>/Product3'
     *  Product: '<S15>/Product5'
     *  Product: '<S15>/Product8'
     *  Sum: '<S15>/Sum'
     */
    rtb_Xr_idx_1 += (rtb_XrDotVv * rtb_Xr_idx_1 * rtb_MathFunction1 +
                     rtb_MathFunction_idx_1) * NLGuidance_U.r;

    /* Sum: '<S3>/Sum8' incorporates:
     *  Inport: '<Root>/Xv'
     *  Inport: '<Root>/r'
     *  Product: '<S15>/Product3'
     *  Product: '<S15>/Product5'
     *  Product: '<S15>/Product8'
     *  Sum: '<S15>/Sum'
     *  Sum: '<S15>/Sum7'
     */
    rtb_Sum8[1] = NLGuidance_U.Xv[1] + rtb_Xr_idx_1;
    rtb_Sum8[2] = ((rtb_XrDotVv * rtb_Xr * rtb_MathFunction1 +
                    rtb_MathFunction1_m) * NLGuidance_U.r + rtb_Xr) +
      NLGuidance_U.Xv[2];

    /* ToWorkspace: '<S3>/To Workspace1' */
    rt_UpdateLogVar((LogVar *)(LogVar*)
                    (NLGuidance_DW.ToWorkspace1_PWORK.LoggedData), &rtb_Sum8[0],
                    0);

    /* Product: '<S17>/i x j' incorporates:
     *  Product: '<S16>/i x j'
     */
    rtb_Xr = rtb_Xr_idx_0 * rtb_Xr_idx_1;

    /* If: '<S3>/If' incorporates:
     *  Constant: '<S3>/Constant1'
     *  Product: '<S17>/i x j'
     *  RelationalOperator: '<S3>/Relational Operator'
     *  Sum: '<S14>/Sum'
     */
    if (rtb_Xr - rtb_Xr < NLGuidance_P.Constant1_Value_k) {
      /* Outputs for IfAction SubSystem: '<S3>/CW' incorporates:
       *  ActionPort: '<S13>/Action Port'
       */
      /* Outport: '<Root>/yout' */
      NLGuidance_CW(rtb_Sum8, NLGuidance_Y.yout);

      /* End of Outputs for SubSystem: '<S3>/CW' */
    } else {
      /* Outputs for IfAction SubSystem: '<S3>/CCW' incorporates:
       *  ActionPort: '<S12>/Action Port'
       */
      /* Outport: '<Root>/yout' */
      NLGuidance_CW(rtb_Sum4, NLGuidance_Y.yout);

      /* End of Outputs for SubSystem: '<S3>/CCW' */
    }

    /* End of If: '<S3>/If' */
    /* End of Outputs for SubSystem: '<S1>/Outer' */
  }

  /* Matfile logging */
  rt_UpdateTXYLogVars(NLGuidance_M->rtwLogInfo, (&NLGuidance_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.02s, 0.0s] */
    if ((rtmGetTFinal(NLGuidance_M)!=-1) &&
        !((rtmGetTFinal(NLGuidance_M)-NLGuidance_M->Timing.taskTime0) >
          NLGuidance_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(NLGuidance_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++NLGuidance_M->Timing.clockTick0)) {
    ++NLGuidance_M->Timing.clockTickH0;
  }

  NLGuidance_M->Timing.taskTime0 = NLGuidance_M->Timing.clockTick0 *
    NLGuidance_M->Timing.stepSize0 + NLGuidance_M->Timing.clockTickH0 *
    NLGuidance_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void NLGuidance_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)NLGuidance_M, 0,
                sizeof(RT_MODEL_NLGuidance_T));
  rtmSetTFinal(NLGuidance_M, 10.0);
  NLGuidance_M->Timing.stepSize0 = 0.02;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    NLGuidance_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(NLGuidance_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(NLGuidance_M->rtwLogInfo, (NULL));
    rtliSetLogT(NLGuidance_M->rtwLogInfo, "tout");
    rtliSetLogX(NLGuidance_M->rtwLogInfo, "");
    rtliSetLogXFinal(NLGuidance_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(NLGuidance_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(NLGuidance_M->rtwLogInfo, 2);
    rtliSetLogMaxRows(NLGuidance_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(NLGuidance_M->rtwLogInfo, 1);

    /*
     * Set pointers to the data and signal info for each output
     */
    {
      static void * rt_LoggedOutputSignalPtrs[] = {
        &NLGuidance_Y.yout[0]
      };

      rtliSetLogYSignalPtrs(NLGuidance_M->rtwLogInfo, ((LogSignalPtrsType)
        rt_LoggedOutputSignalPtrs));
    }

    {
      static int_T rt_LoggedOutputWidths[] = {
        3
      };

      static int_T rt_LoggedOutputNumDimensions[] = {
        1
      };

      static int_T rt_LoggedOutputDimensions[] = {
        3
      };

      static boolean_T rt_LoggedOutputIsVarDims[] = {
        0
      };

      static void* rt_LoggedCurrentSignalDimensions[] = {
        (NULL)
      };

      static int_T rt_LoggedCurrentSignalDimensionsSize[] = {
        4
      };

      static BuiltInDTypeId rt_LoggedOutputDataTypeIds[] = {
        SS_DOUBLE
      };

      static int_T rt_LoggedOutputComplexSignals[] = {
        0
      };

      static RTWPreprocessingFcnPtr rt_LoggingPreprocessingFcnPtrs[] = {
        (NULL)
      };

      static const char_T *rt_LoggedOutputLabels[] = {
        "" };

      static const char_T *rt_LoggedOutputBlockNames[] = {
        "NLGuidance/yout" };

      static RTWLogDataTypeConvert rt_RTWLogDataTypeConvert[] = {
        { 0, SS_DOUBLE, SS_DOUBLE, 0, 0, 0, 1.0, 0, 0.0 }
      };

      static RTWLogSignalInfo rt_LoggedOutputSignalInfo[] = {
        {
          1,
          rt_LoggedOutputWidths,
          rt_LoggedOutputNumDimensions,
          rt_LoggedOutputDimensions,
          rt_LoggedOutputIsVarDims,
          rt_LoggedCurrentSignalDimensions,
          rt_LoggedCurrentSignalDimensionsSize,
          rt_LoggedOutputDataTypeIds,
          rt_LoggedOutputComplexSignals,
          (NULL),
          rt_LoggingPreprocessingFcnPtrs,

          { rt_LoggedOutputLabels },
          (NULL),
          (NULL),
          (NULL),

          { rt_LoggedOutputBlockNames },

          { (NULL) },
          (NULL),
          rt_RTWLogDataTypeConvert
        }
      };

      rtliSetLogYSignalInfo(NLGuidance_M->rtwLogInfo, rt_LoggedOutputSignalInfo);

      /* set currSigDims field */
      rt_LoggedCurrentSignalDimensions[0] = &rt_LoggedOutputWidths[0];
    }

    rtliSetLogY(NLGuidance_M->rtwLogInfo, "yout");
  }

  /* states (dwork) */
  (void) memset((void *)&NLGuidance_DW, 0,
                sizeof(DW_NLGuidance_T));

  /* external inputs */
  (void)memset(&NLGuidance_U, 0, sizeof(ExtU_NLGuidance_T));

  /* external outputs */
  (void) memset(&NLGuidance_Y.yout[0], 0,
                3U*sizeof(real_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(NLGuidance_M->rtwLogInfo, 0.0, rtmGetTFinal
    (NLGuidance_M), NLGuidance_M->Timing.stepSize0, (&rtmGetErrorStatus
    (NLGuidance_M)));

  /* SetupRuntimeResources for IfAction SubSystem: '<S1>/Inner' */

  /* SetupRuntimeResources for ToWorkspace: '<S2>/To Workspace1' */
  {
    int_T dimensions[1] = { 3 };

    NLGuidance_DW.ToWorkspace1_PWORK_h.LoggedData = rt_CreateLogVar(
      NLGuidance_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(NLGuidance_M),
      NLGuidance_M->Timing.stepSize0,
      (&rtmGetErrorStatus(NLGuidance_M)),
      "cmd1",
      SS_DOUBLE,
      0,
      0,
      0,
      3,
      1,
      dimensions,
      NO_LOGVALDIMS,
      (NULL),
      (NULL),
      0,
      1,
      0.02,
      1);
    if (NLGuidance_DW.ToWorkspace1_PWORK_h.LoggedData == (NULL))
      return;
  }

  /* SetupRuntimeResources for ToWorkspace: '<S2>/To Workspace2' */
  {
    int_T dimensions[1] = { 3 };

    NLGuidance_DW.ToWorkspace2_PWORK.LoggedData = rt_CreateLogVar(
      NLGuidance_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(NLGuidance_M),
      NLGuidance_M->Timing.stepSize0,
      (&rtmGetErrorStatus(NLGuidance_M)),
      "cmd2",
      SS_DOUBLE,
      0,
      0,
      0,
      3,
      1,
      dimensions,
      NO_LOGVALDIMS,
      (NULL),
      (NULL),
      0,
      1,
      0.02,
      1);
    if (NLGuidance_DW.ToWorkspace2_PWORK.LoggedData == (NULL))
      return;
  }

  /* End of SetupRuntimeResources for SubSystem: '<S1>/Inner' */

  /* SetupRuntimeResources for IfAction SubSystem: '<S1>/Outer' */

  /* SetupRuntimeResources for ToWorkspace: '<S3>/To Workspace' */
  {
    int_T dimensions[1] = { 3 };

    NLGuidance_DW.ToWorkspace_PWORK.LoggedData = rt_CreateLogVar(
      NLGuidance_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(NLGuidance_M),
      NLGuidance_M->Timing.stepSize0,
      (&rtmGetErrorStatus(NLGuidance_M)),
      "Xap2",
      SS_DOUBLE,
      0,
      0,
      0,
      3,
      1,
      dimensions,
      NO_LOGVALDIMS,
      (NULL),
      (NULL),
      0,
      1,
      0.02,
      1);
    if (NLGuidance_DW.ToWorkspace_PWORK.LoggedData == (NULL))
      return;
  }

  /* SetupRuntimeResources for ToWorkspace: '<S3>/To Workspace1' */
  {
    int_T dimensions[1] = { 3 };

    NLGuidance_DW.ToWorkspace1_PWORK.LoggedData = rt_CreateLogVar(
      NLGuidance_M->rtwLogInfo,
      0.0,
      rtmGetTFinal(NLGuidance_M),
      NLGuidance_M->Timing.stepSize0,
      (&rtmGetErrorStatus(NLGuidance_M)),
      "Xap1",
      SS_DOUBLE,
      0,
      0,
      0,
      3,
      1,
      dimensions,
      NO_LOGVALDIMS,
      (NULL),
      (NULL),
      0,
      1,
      0.02,
      1);
    if (NLGuidance_DW.ToWorkspace1_PWORK.LoggedData == (NULL))
      return;
  }

  /* End of SetupRuntimeResources for SubSystem: '<S1>/Outer' */
}

/* Model terminate function */
void NLGuidance_terminate(void)
{
  /* (no terminate code required) */
}
