/*
 * NLGuidance_private.h
 *
 * Code generation for model "NLGuidance".
 *
 * Model version              : 1.72
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Fri Aug 27 10:10:14 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_NLGuidance_private_h_
#define RTW_HEADER_NLGuidance_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "NLGuidance.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmSetTFinal
# define rtmSetTFinal(rtm, val)        ((rtm)->Timing.tFinal = (val))
#endif

extern void NLGuidance_CW(const real_T rtu_Xap1[3], real_T rty_yout[3]);

#endif                                 /* RTW_HEADER_NLGuidance_private_h_ */
